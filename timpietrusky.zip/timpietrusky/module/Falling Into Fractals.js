export default {
    "props": {
      "modvwaveaspeed": {
        "type": "float",
        "default": 0.15,
        "label": "Wave A Speed",
        "min": 0.0,
        "max": 10.0,
      },
      "modvwavebspeed": {
        "type": "float",
        "default": 2.1,
        "label": "Wave B Speed",
        "min": 0.0,
        "max": 10.0,
      },
      "modvdepth": {
        "type": "float",
        "default": 3.7,
        "label": "Depth",
        "min": 0.0,
        "max": 10.0,
      },
      "mX": {
        "type": "float",
        "default": 0.5,
        "label": "Mouse X"
      },
      "mY": {
        "type": "float",
        "default": 0.5,
        "label": "Mouse Y"
      },
      "mZ": {
        "type": "float",
        "default": 0.5,
        "label": "Mouse Z"
      },
      "mW": {
        "type": "float",
        "default": 0.5,
        "label": "Mouse W"
      }
    },
    "fragmentShader": `uniform float modvwaveaspeed;
    uniform float modvwavebspeed;
    
    void mainImage( out vec4 fragColor, in vec2 fragCoord )
    {
        vec2 uv = fragCoord.xy / iResolution.xy;
    
        float w = iResolution.x;
        float h = iResolution.y;
        
        float aspectRatio = h / w;
        
        uv.y *= aspectRatio;
        uv.y -= (aspectRatio - 1.) * 0.5;
        
        vec2 cUV = uv - .5;
        
        float _WaveA = modvwaveaspeed;
        float _WaveB = modvwavebspeed;
        
        vec4 _ColorA = vec4(.5, .4, .5,  1);
        vec4 _ColorB = vec4(.1, .1, .5,  1);
    
        float w0 = sin(_WaveA / abs(cUV.x) + iTime * _WaveB);
        float w1 = sin(_WaveA / abs(cUV.y) + iTime * _WaveB);
        float w2 = sin(_WaveB / abs(cUV.x) + iTime * _WaveA);
        float w3 = sin(_WaveB / abs(cUV.y) + iTime * _WaveA);
        
        vec4 c = _ColorA * w0 * w1 + _ColorB * w2 * w3;
        
        // Output to screen
        fragColor = vec4(c.xyz * clamp(c.a, 0., 1.) ,1.);
    }`,
    "meta": {
      "name": "Falling Into Fractals",
      "author": "MaxMaletin",
      "version": 0.1,
      "type": "shader",
      "previewWithOutput": true,
      "flipY": false
    }
  }