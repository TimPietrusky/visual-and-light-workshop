/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {
    "modvwaveaspeed": {
      "type": "float",
      "default": 0.15,
      "label": "Wave A Speed",
      "min": 0.0,
      "max": 10.0
    },
    "modvwavebspeed": {
      "type": "float",
      "default": 2.1,
      "label": "Wave B Speed",
      "min": 0.0,
      "max": 10.0
    },
    "modvdepth": {
      "type": "float",
      "default": 3.7,
      "label": "Depth",
      "min": 0.0,
      "max": 10.0
    },
    "mX": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse X"
    },
    "mY": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Y"
    },
    "mZ": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Z"
    },
    "mW": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse W"
    }
  },
  "fragmentShader": "uniform float modvwaveaspeed;\n    uniform float modvwavebspeed;\n    \n    void mainImage( out vec4 fragColor, in vec2 fragCoord )\n    {\n        vec2 uv = fragCoord.xy / iResolution.xy;\n    \n        float w = iResolution.x;\n        float h = iResolution.y;\n        \n        float aspectRatio = h / w;\n        \n        uv.y *= aspectRatio;\n        uv.y -= (aspectRatio - 1.) * 0.5;\n        \n        vec2 cUV = uv - .5;\n        \n        float _WaveA = modvwaveaspeed;\n        float _WaveB = modvwavebspeed;\n        \n        vec4 _ColorA = vec4(.5, .4, .5,  1);\n        vec4 _ColorB = vec4(.1, .1, .5,  1);\n    \n        float w0 = sin(_WaveA / abs(cUV.x) + iTime * _WaveB);\n        float w1 = sin(_WaveA / abs(cUV.y) + iTime * _WaveB);\n        float w2 = sin(_WaveB / abs(cUV.x) + iTime * _WaveA);\n        float w3 = sin(_WaveB / abs(cUV.y) + iTime * _WaveA);\n        \n        vec4 c = _ColorA * w0 * w1 + _ColorB * w2 * w3;\n        \n        // Output to screen\n        fragColor = vec4(c.xyz * clamp(c.a, 0., 1.) ,1.);\n    }",
  "meta": {
    "name": "Falling Into Fractals",
    "author": "MaxMaletin",
    "version": 0.1,
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false
  }
};

/***/ })
/******/ ]);