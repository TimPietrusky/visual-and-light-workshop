/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

exports.default = {
  meta: {
    // this tells modV our Module should be used with the 2d renderer
    type: '2d',
    author: 'Tim Pietrusky',
    version: '1.0.0',

    // our Module's name
    name: 'NERDDISCO UltraSquare'
  },

  props: {
    superWidth: {
      type: 'int',
      label: 'Width',
      min: 0,
      max: 500,
      default: 50,
      strict: true
    },

    superHeight: {
      type: 'int',
      label: 'Height',
      min: 0,
      max: 900,
      default: 50,
      strict: true
    }
  },

  draw: function draw(_ref) {
    var _ref$canvas = _ref.canvas,
        width = _ref$canvas.width,
        height = _ref$canvas.height,
        context = _ref.context;
    var superWidth = this.superWidth,
        superHeight = this.superHeight;


    var square = new ndUltraSquare({
      context: context,
      canvasWidth: width,
      canvasHeight: height,
      width: superWidth * 2,
      height: superHeight * 2,
      color: -40
    });

    square.draw();

    var square2 = new ndUltraSquare({
      context: context,
      canvasWidth: width,
      canvasHeight: height,
      width: superWidth * 1.5,
      height: superHeight * 1.5,
      color: 0
    });

    square2.draw();

    var square3 = new ndUltraSquare({
      context: context,
      canvasWidth: width,
      canvasHeight: height,
      width: superWidth,
      height: superHeight,
      color: 80
    });

    square3.draw();
  }
};

var ndUltraSquare = function () {
  function ndUltraSquare(args) {
    _classCallCheck(this, ndUltraSquare);

    this.color = args.color || '50';

    this.x = args.x || 0;
    this.y = args.y || 0;
    this.width = args.width || 0;
    this.height = args.height || 0;
    this.angle = args.angle || 0;

    this.internal_angle = this.angle;

    this.ctx = args.context;

    this.canvasWidth = args.canvasWidth;
    this.canvasHeight = args.canvasHeight;
  }

  _createClass(ndUltraSquare, [{
    key: 'draw',
    value: function draw() {
      this.ctx.save();

      this.ctx.globalCompositeOperation = 'lighten';

      this.internal_x = this.canvasWidth / 2 + this.x; // eslint-disable-line
      this.internal_y = this.canvasHeight / 2 + this.y; // eslint-disable-line

      // this.audio.frequency = this.ndAudio.audioGroupedFrequencyData[this.range].value;
      // this.internal_color = this.color + (360 / 255 * this.audio.frequency);
      // this.internal_r = this.audio.frequency / 255 * this.r;

      this.internal_color = this.color;

      this.internal_width = this.width;
      this.internal_height = this.height;

      this.ctx.beginPath();

      this.ctx.globalAlpha = 0.05;

      this.angle_factor = 2;

      this.ctx.fillStyle = 'hsla(' + this.internal_color + ', 100%, 60%, .65)';

      this.ctx.translate(this.internal_x, this.internal_y);

      this.ctx.rotate(this.internal_angle * Math.PI / 180);

      // this.factor = 2.5 * (this.audio.frequency / 255);
      this.factor = 2.5;

      this.internal_width *= this.factor;
      this.internal_height *= this.factor;

      this.ctx.fillRect(-(this.internal_width / 2), -(this.internal_height / 2), this.internal_width, this.internal_height);

      this.factor *= 0.45;

      this.internal_width *= this.factor;
      this.internal_height *= this.factor;

      this.ctx.globalAlpha = 0.5;
      this.ctx.fillRect(-(this.internal_width / 2), -(this.internal_height / 2), this.internal_width, this.internal_height);

      this.internal_angle += this.angle_factor;

      if (this.internal_angle > 360) {
        this.internal_angle = 0;
      }

      this.ctx.closePath();
      this.ctx.stroke();
      this.ctx.fill();
      this.ctx.restore();
    } // / draw

  }]);

  return ndUltraSquare;
}();

/***/ })
/******/ ]);