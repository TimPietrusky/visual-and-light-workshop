/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {},
  "fragmentShader": "// Minecraft Blocks. Created by Reinder Nijhoff 2013\n// @reindernijhoff\n//\n// https://www.shadertoy.com/view/MdlGz4\n//\n// port of javascript minecraft: http://jsfiddle.net/uzMPU/\n// original code by Markus Persson: https://twitter.com/notch/status/275331530040160256\n\nfloat hash( float n ) {\n    return fract(sin(n)*43758.5453);\n}\n\n// port of minecraft\n\nbool getMaterialColor( int i, vec2 coord, out vec3 color ) {\n\t// 16x16 tex\n\tvec2 uv = floor( coord );\n\n    float n = uv.x + uv.y*347.0 + 4321.0 * float(i);\n\tfloat h = hash(n);\n\t\t\n    float br = 1. - h * (96./255.\n\t\t\t\t\t\t);\n\tcolor = vec3( 150./255., 108./255.,  74./255.); // 0x966C4A;\n\t\n\tif (i == 4) {\n\t\tcolor = vec3( 127./255., 127./255., 127./255.); // 0x7F7F7F;\n\t}\n\t\n\tfloat xm1 = mod((uv.x * uv.x * 3. + uv.x * 81.) / 4., 4.);\n\t\n\tif (i == 1) {\n\t\tif( uv.y < (xm1 + 18.)) {\n\t\t\tcolor = vec3( 106./255., 170./255.,  64./255.); // 0x6AAA40;\n\t\t} else if (uv.y < (xm1 + 19.)) {\n\t\t\tbr = br * (2. / 3.);\n\t\t}\n\t}\n\t\n\tif (i == 7) {\n\t\tcolor = vec3( 103./255., 82./255.,  49./255.); // 0x675231;\n\t\tif (uv.x > 0. && uv.x < 15.\n\t\t\t&& ((uv.y > 0. && uv.y < 15.) || (uv.y > 32. && uv.y < 47.))) {\n\t\t\tcolor = vec3( 188./255., 152./255.,  98./255.); // 0xBC9862;\n\t\t\tfloat xd = (uv.x - 7.);\n\t\t\tfloat yd = (mod(uv.y, 16.) - 7.);\n\t\t\tif (xd < 0.)\n\t\t\t\txd = 1. - xd;\n\t\t\tif (yd < 0.)\n\t\t\t\tyd = 1. - yd;\n\t\t\tif (yd > xd)\n\t\t\t\txd = yd;\n\t\t\t\n\t\t\tbr = 1. - (h * (32./255.) + mod(xd, 4.) * (32./255.));\n\t\t} else if ( h < 0.5 ) {\n\t\t\tbr = br * (1.5 - mod(uv.x, 2.));\n\t\t}\n\t}\n\t\n\tif (i == 5) {\n\t\tcolor = vec3( 181./255.,  58./255.,  21./255.); // 0xB53A15;\n\t\tif ( mod(uv.x + (floor(uv.y / 4.) * 5.), 8.) == 0. || mod( uv.y, 4.) == 0.) {\n\t\t\tcolor = vec3( 188./255., 175./255., 165./255.); // 0xBCAFA5;\n\t\t}\n\t}\n\tif (i == 9) {\n\t\tcolor = vec3(  64./255.,  64./255., 255./255.); // 0x4040ff;\n\t}\n\t\n\tfloat brr = br;\n\tif (uv.y >= 32.)\n\t\tbrr /= 2.;\n\t\n\tif (i == 8) {\n\t\tcolor = vec3(  80./255., 217./255.,  55./255.); // 0x50D937;\n\t\tif ( h < 0.5) {\n\t\t\treturn false;\n\t\t}\n\t}\n\t\n\tcolor *= brr;\n\t\n\treturn true;\n}\n\nint getMap( vec3 pos ) {\t\n\tvec3 posf = floor( (pos - vec3(32.))  );\n    \n\tfloat n = posf.x + posf.y*517.0 + 1313.0*posf.z;\n    float h = hash(n);\n\t\n\tif( h > sqrt( sqrt( dot( posf.yz, posf.yz )*0.16 ) ) - 0.8  ) {\n        return 0;\n\t}\t\n\t\n\treturn int( hash( n * 465.233 ) * 16. );\n}\n\nvec3 renderMinecraft( vec2 uv ) {\n    float xRot = sin( iTime*0.5 ) * 0.4 + (3.1415 / 2.);\n    float yRot = cos( iTime*0.5 ) * 0.4;\n    float yCos = cos(yRot);\n    float ySin = sin(yRot);\n    float xCos = cos(xRot);\n    float xSin = sin(xRot);\n\n\tvec3 opos = vec3( 32.5 + iTime * 6.4, 32.5, 32.5 );\n\t\n\tfloat gggxd = (uv.x - 0.5) * (iResolution.x / iResolution.y );\n\tfloat ggyd = (1.-uv.y - 0.5);\n\tfloat ggzd = 1.;\n\t\n\tfloat gggzd = ggzd * yCos + ggyd * ySin;\n\t\n\tvec3 _posd = vec3( gggxd * xCos + gggzd * xSin,\n\t\t\t\t\t   ggyd * yCos - ggzd * ySin,\n\t\t\t\t\t   gggzd * xCos - gggxd * xSin );\n\t\n\tvec3 col = vec3( 0. );\n\tfloat br = 1.;\n\tvec3 bdist = vec3( 255. - 100., 255. -   0., 255. -  50.  );\n\tfloat ddist = 0.;\n\t\n\tfloat closest = 32.;\n\t\n\tfor ( int d = 0; d < 3; d++) {\n\t\tfloat dimLength = _posd[d];\n\t\t\n\t\tfloat ll = abs( 1. / dimLength );\n\t\tvec3 posd = _posd * ll;;\n\t\t\n\t\tfloat initial = fract( opos[d] );\n\t\tif (dimLength > 0.) initial = 1. - initial;\n\t\t\n\t\tfloat dist = ll * initial;\n\t\t\n\t\tvec3 pos = opos + posd * initial;\n\t\t\n\t\tif (dimLength < 0.) {\n\t\t\tpos[d] -= 1.;\n\t\t}\n\t\t\n\t\tfor (int i=0; i<30; i++) {\n\t\t\tif( dist > closest )continue;\n\t\t\t\n\t\t\t//int tex = getMap( mod( pos, 64. ) );\n\t\t\tint tex = getMap( pos );\n\t\t\t\n\t\t\tif (tex > 0) {\n\t\t\t\tvec2 texcoord;\n\t\t\t\ttexcoord.x = mod(((pos.x + pos.z) * 16.), 16.);\n\t\t\t\ttexcoord.y = mod((pos.y * 16.), 16.) + 16.;\n\t\t\t\tif (d == 1) {\n\t\t\t\t\ttexcoord.x = mod(pos.x * 16., 16.);\n\t\t\t\t\ttexcoord.y = mod(pos.z * 16., 16.);\n\t\t\t\t\tif (posd.y < 0.)\n\t\t\t\t\t\ttexcoord.y += 32.;\n\t\t\t\t}\n\t\t\t\t\n\t\t\t\tif ( getMaterialColor( tex, texcoord, col ) ) {\n\t\t\t\t\tddist = 1. - (dist / 32.);\n\t\t\t\t\tbr = bdist[d];\n\t\t\t\t\tclosest = dist;\n\t\t\t\t}\n\t\t\t}\n\t\t\tpos += posd;\n\t\t\tdist += ll;\n\t\t}\n\t}\n\t\n\treturn col * ddist * (br/255.);\n}\n\nvoid mainImage( out vec4 fragColor, in vec2 fragCoord )\n{\n\tvec2 uv = fragCoord.xy / iResolution.xy;\n\t\n\tfragColor = vec4( renderMinecraft( uv ) ,1.0);\n}",
  "meta": {
    "name": "Minecraft Blocks",
    "author": "reinder",
    "version": 0.1,
    "uniforms": {},
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false,
    "originalName": "Minecraft Blocks",
    "alpha": 1,
    "enabled": false,
    "compositeOperation": "normal"
  }
};

/***/ })
/******/ ]);