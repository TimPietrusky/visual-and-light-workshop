/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {
    "modvstrength": {
      "type": "float",
      "default": 2.0,
      "label": "Strength",
      "min": 0.0,
      "max": 100.0,
      "abs": true
    },
    "mX": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse X"
    },
    "mY": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Y"
    },
    "mZ": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Z"
    },
    "mW": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse W"
    }
  },
  "fragmentShader": "float burn;\n    uniform float modvstrength;\n    \n    mat2 rot(float a)\n    {\n        float s=sin(a), c=cos(a);\n        return mat2(s, c, -c, s);\n    }\n    \n    float map(vec3 p)\n    {\n        float d = max(max(abs(p.x), abs(p.y)), abs(p.z)) - .5;\n        burn = d;\n        \n        mat2 rm = rot(-iTime/3. + length(p));\n        p.xy *= rm, p.zy *= rm;\n        \n        vec3 q = abs(p) - iTime;\n        q = abs(q - round(q));\n        \n        rm = rot(iTime);\n        q.xy *= rm, q.xz *= rm;\n        \n        d = min(d, min(min(length(q.xy), length(q.yz)), length(q.xz)) + .01);\n        \n        burn = pow(d - burn, 2.);\n        \n        return d;\n    }\n    \n    void mainImage( out vec4 fragColor, in vec2 fragCoord )\n    {\n        vec3 rd = normalize(vec3(2.*fragCoord-iResolution.xy, iResolution.y)), \n             ro = vec2(0, -2).xxy;\n        \n        mat2 r1 = rot(iTime/4.), r2 = rot(iTime/2.);\n        rd.xz *= r1, ro.xz *= r1, rd.yz *= r2, ro.yz *= r2;\n        \n        float t = .0, i = modvstrength * (1. - exp(-.2*iTime-.1));\n        for(;i-->0.;)t += map(ro+rd*t) / 2.;\n        \n        fragColor = vec4(1.-burn, exp(-t), exp(-t/2.), 1);\n    }",
  "meta": {
    "name": "Fire Storm Cube",
    "author": "slerpy",
    "version": 0.1,
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false
  }
};

/***/ })
/******/ ]);