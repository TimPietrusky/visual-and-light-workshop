/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {
    "mX": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse X"
    },
    "mY": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Y"
    },
    "mZ": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Z"
    },
    "mW": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse W"
    }
  },
  "fragmentShader": "uniform float mX;\nuniform float mY;\nuniform float mZ;\nuniform float mW;\n// \"Red Canyon 2\" by dr2 - 2017\n// License: Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License\n\nfloat PrCylDf (vec3 p, float r, float h);\nfloat PrCapsDf (vec3 p, float r, float h);\nfloat PrFlatCylDf (vec3 p, float rhi, float rlo, float h);\nfloat Noisefv2 (vec2 p);\nfloat Noisefv3a (vec3 p);\nfloat Fbm3 (vec3 p);\nvec3 VaryNf (vec3 p, vec3 n, float f);\nfloat SmoothMin (float a, float b, float r);\nfloat SmoothMax (float a, float b, float r);\nfloat SmoothBump (float lo, float hi, float w, float x);\nmat3 AxToRMat (vec3 vz, vec3 vy);\nvec2 Rot2D (vec2 q, float a);\n\n#define N_FLYER 3\n\nint idObj, idFlmGrp, idLsrGrp;\nmat3 flyerMat[N_FLYER], flMat;\nvec3 flyerPos[N_FLYER], flPos, qHit, qHitFlm, qHitLsr, sunDir, flmCylPos, lsrCylPos,\n   trkF, trkA;\nfloat dstFar, tCur, fusLen, flmCylRad, flmCylLen, lsrCylRad, lsrCylLen, vFly;\nconst int idFus = 11, idEngO = 12, idEngI = 13, idWng = 14, idCan = 15;\nconst float pi = 3.14159;\n\nvec3 SkyBg (vec3 rd)\n{\n  return mix (vec3 (0.2, 0.2, 0.9), vec3 (0.4, 0.4, 0.55),\n     1. - max (rd.y, 0.));\n}\n\nvec3 SkyCol (vec3 ro, vec3 rd)\n{\n  vec3 p, q, cSun, clCol, col;\n  float fCloud, cloudLo, cloudRngI, atFac, colSum, attSum, s,\n     att, a, dDotS, ds;\n  const int nLay = 60;\n  cloudLo = 200.;  cloudRngI = 1./200.;  atFac = 0.035;\n  fCloud = 0.45;\n  if (rd.y > 0.) {\n    fCloud = clamp (fCloud, 0., 1.);\n    dDotS = max (dot (rd, sunDir), 0.);\n    ro.x += 3. * tCur;\n    p = ro;\n    p.xz += (cloudLo - p.y) * rd.xz / rd.y;\n    p.y = cloudLo;\n    ds = 1. / (cloudRngI * rd.y * (2. - rd.y) * float (nLay));\n    colSum = 0.;  attSum = 0.;\n    s = 0.;  att = 0.;\n    for (int j = 0; j < nLay; j ++) {\n      q = p + rd * s;\n      att += atFac * max (fCloud - Fbm3 (0.007 * q), 0.);\n      a = (1. - attSum) * att;\n      colSum += a * (q.y - cloudLo) * cloudRngI;\n      attSum += a;  s += ds;\n      if (attSum >= 1.) break;\n    }\n    colSum += 0.5 * min ((1. - attSum) * pow (dDotS, 3.), 1.);\n    clCol = vec3 (1.) * 2.8 * (colSum + 0.05);\n    cSun = vec3 (1.) * clamp ((min (pow (dDotS, 1500.) * 2., 1.) +\n       min (pow (dDotS, 10.) * 0.75, 1.)), 0., 1.);\n    col = clamp (mix (SkyBg (rd) + cSun, clCol, attSum), 0., 1.);\n    col = mix (col, SkyBg (rd), pow (1. - rd.y, 16.));\n  } else col = SkyBg (rd);\n  return col;\n}\n\nfloat GrndDf (vec3 p)\n{\n  float d, s;\n  s = p.y - 3.;\n  d = SmoothMin (12. + 4. * sin (0.019 * p.z) -\n     abs (p.x - dot (trkA, sin (trkF * p.z))) +\n     s * (0.3 - 0.05 * s), 3. + p.y, 2.);\n  d = SmoothMax (d, - (8. + 1.1 * sin (0.022 * p.z) - p.y), 1.);\n  d += 2.3 * Noisefv2 (0.2 * p.xz) + 1.1 * Noisefv2 (0.6 * p.xz) +\n     0.3 * Noisefv2 (1.1 * p.xz);\n  return d;\n}\n\nfloat GrndRay (vec3 ro, vec3 rd)\n{\n  vec3 p;\n  float dHit, h, s, sLo, sHi;\n  s = 0.;\n  sLo = 0.;\n  dHit = dstFar;\n  for (int j = 0; j < 150; j ++) {\n    p = ro + s * rd;\n    h = GrndDf (p);\n    if (h < 0.) break;\n    sLo = s;\n    s += 0.5 * h + 0.005 * s;\n    if (s > dstFar) break;\n  }\n  if (h < 0.) {\n    sHi = s;\n    for (int j = 0; j < 4; j ++) {\n      s = 0.5 * (sLo + sHi);\n      p = ro + s * rd;\n      h = step (0., GrndDf (p));\n      sLo += h * (s - sLo);\n      sHi += (1. - h) * (s - sHi);\n    }\n    dHit = sHi;\n  }\n  return dHit;\n}\n\nvec3 GrndNf (vec3 p)\n{\n  vec3 e;\n  float s;\n  e = vec3 (0.01, 0., 0.);\n  s = GrndDf (p);\n  return normalize (vec3 (GrndDf (p + e.xyy) - s, e.x,\n     GrndDf (p + e.yyx) - s));\n}\n\nvec4 GrndCol (vec3 p, vec3 n)\n{\n  vec4 col, wCol, bCol;\n  wCol = mix (vec4 (0.5, 0.4, 0.4, 1.), vec4 (0.22, 0.2, 0.2, 1.),\n     clamp (1.4 * (Noisefv2 (5. * p.xy +\n     vec2 (0., 3.7 * sin (0.17 * p.z))) +\n     Noisefv2 (p.zy * vec2 (5., 10.3))) - 1., 0., 1.));\n  bCol = mix (vec4 (0.2, 0.4, 0.2, 0.), vec4 (0.2, 0.2, 0., 0.),\n     clamp (Noisefv2 (2. * p.xz) - 0.3, 0., 1.));\n  col = mix (wCol, bCol, smoothstep (0.6, 0.9, n.y));\n  col.w *= clamp (1. - 2. * n.y, 0., 1.);\n  return col;\n}\n\nfloat GrndSShadow (vec3 ro, vec3 rd)\n{\n  float sh, d, h;\n  sh = 1.;\n  d = 1.;\n  for (int j = 0; j < 16; j ++) {\n    h = GrndDf (ro + rd * d);\n    sh = min (sh, smoothstep (0., 0.05 * d, h));\n    d += 1.;\n    if (sh < 0.05) break;\n  }\n  return sh;\n}\n\nfloat FlmDf (vec3 p)\n{\n  vec3 q, qq;\n  float d, dMin, r, s;\n  dMin = dstFar;\n  s = (0.55 / sqrt (2.)) * fusLen;\n  for (int k = 0; k < N_FLYER; k ++) {\n    q = flyerMat[k] * (p - flyerPos[k]) - flmCylPos;\n    r = flmCylRad * (0.6 + 0.4 * q.z / flmCylLen);\n    qq = q + vec3 (s, s, 0.);\n    d = PrCylDf (qq, r, flmCylLen);\n    if (d < dMin) { dMin = d;  qHitFlm = qq;  idFlmGrp = k; }\n    qq = q + vec3 (s, - s, 0.);\n    d = PrCylDf (qq, r, flmCylLen);\n    if (d < dMin) { dMin = d;  qHitFlm = qq;  idFlmGrp = k; }\n    qq = q + vec3 (- s, - s, 0.);\n    d = PrCylDf (qq, r, flmCylLen);\n    if (d < dMin) { dMin = d;  qHitFlm = qq;  idFlmGrp = k; }\n    qq = q + vec3 (- s, s, 0.);\n    d = PrCylDf (qq, r, flmCylLen);\n    if (d < dMin) { dMin = d;  qHitFlm = qq;  idFlmGrp = k; }\n  }\n  return dMin;\n}\n\nfloat FlmRay (vec3 ro, vec3 rd)\n{\n  float dHit, d;\n  dHit = 0.;\n  for (int j = 0; j < 50; j ++) {\n    d = FlmDf (ro + dHit * rd);\n    dHit += d;\n    if (d < 0.001 || dHit > dstFar) break;\n  }\n  if (d >= 0.001) dHit = dstFar;\n  return dHit;\n}\n\nfloat LsrDf (vec3 p)\n{\n  vec3 q;\n  float d, dMin;\n  dMin = dstFar;\n  for (int k = 0; k < N_FLYER; k ++) {\n    q = flyerMat[k] * (p - flyerPos[k]);\n    q -= lsrCylPos;\n    d = PrCylDf (q, lsrCylRad, lsrCylLen);\n    if (d < dMin) { dMin = d;  qHitLsr = q;  idLsrGrp = k; }\n    q.x += 2. * lsrCylPos.x;\n    d = PrCylDf (q, lsrCylRad, lsrCylLen);\n    if (d < dMin) { dMin = d;  qHitLsr = q;  idLsrGrp = k; }\n  }\n  return dMin;\n}\n\nfloat LsrRay (vec3 ro, vec3 rd)\n{\n  float dHit, d;\n  dHit = 0.;\n  for (int j = 0; j < 50; j ++) {\n    d = LsrDf (ro + dHit * rd);\n    dHit += d;\n    if (d < 0.001 || dHit > dstFar) break;\n  }\n  if (d >= 0.001) dHit = dstFar;\n  return dHit;\n}\n\nfloat FlyerDf (vec3 p)\n{\n  vec3 q;\n  float dMin, d, wr, ws;\n  dMin = dstFar / 0.8;\n  p.z -= 0.4 * fusLen;\n  q = p;\n  q.xy = Rot2D (q.xy, pi / 4.);\n  wr = 0.6 + q.z / fusLen;\n  wr = (0.14 - 0.1 * wr * wr) * fusLen;\n  q.z -= 0.3 * fusLen;\n  d = min (PrCapsDf (q * vec3 (0.7, 1., 0.7), wr, fusLen),\n     PrCapsDf (q * vec3 (1., 0.7, 0.7), wr, fusLen));\n  q.z += 0.3 * fusLen;\n  d = SmoothMin (d, PrCapsDf (q, 0.1 * fusLen, 0.5 * fusLen), 0.01 * fusLen);\n  if (d < dMin) { dMin = d;  idObj = idFus;  qHit = q; }\n  q = p;\n  q.xy = Rot2D (q.xy, 2. * pi *\n     (floor (4. * atan (q.y, - q.x) / (2. * pi)) + 0.5) / 4.);\n  q.xz -= vec2 (-0.55, -0.8) * fusLen;\n  ws = q.z / (0.4 * fusLen);\n  wr = ws - 0.1;\n  d = max (PrCylDf (q, (0.09 - 0.05 * wr * wr) * fusLen, 0.35 * fusLen),\n     - PrCylDf (q, 0.05 * fusLen, 0.36 * fusLen));\n  if (d < dMin) { dMin = d;  idObj = idEngO;  qHit = q; }\n  d = min (PrCylDf (q, (0.04 - 0.038 * ws * ws) * fusLen, 0.38 * fusLen),\n     PrCylDf (q - vec3 (0., 0., 0.03 * fusLen), 0.05 * fusLen, 0.28 * fusLen));\n  if (d < dMin) { dMin = d;  idObj = idEngI;  qHit = q; }\n  q.xz -= vec2 (0.3, -0.05) * fusLen;\n  q.xz = Rot2D (q.xz, 0.05 * pi);\n  d = PrFlatCylDf (q.zyx, 0.2, 0.01, 0.27) * fusLen;\n  if (d < dMin) { dMin = d;  idObj = idWng;  qHit = q; }\n  q = p;\n  q.x = abs (q.x);\n  q.xz -= fusLen * vec2 (0.1, 0.2);\n  d = PrFlatCylDf (q.zyx, 0.03 * fusLen, 0.01 * fusLen, 0.1 * fusLen);\n  q.x -= 0.1 * fusLen;\n  d = min (d, PrCapsDf (q, 0.02 * fusLen, 0.1 * fusLen));\n  if (d < dMin) { dMin = d;  idObj = idCan;  qHit = q; }\n  return 0.8 * dMin;\n}\n\nfloat ObjDf (vec3 p)\n{\n  float dMin;\n  dMin = dstFar;\n  for (int k = 0; k < N_FLYER; k ++) {\n    dMin = min (dMin, FlyerDf (flyerMat[k] * (p - flyerPos[k])));\n  }\n  return dMin;\n}\n\nfloat ObjRay (vec3 ro, vec3 rd)\n{\n  vec3 rom[N_FLYER], rdm[N_FLYER], qHitF;\n  float dHit, d, df;\n  int idObjF;\n  for (int k = 0; k < N_FLYER; k ++) {\n    rom[k] = flyerMat[k] * (ro - flyerPos[k]);\n    rdm[k] = flyerMat[k] * rd;\n  }\n  dHit = 0.;\n  for (int j = 0; j < 120; j ++) {\n    df = dstFar;\n    for (int k = 0; k < N_FLYER; k ++) {\n      d = FlyerDf (rom[k] + dHit * rdm[k]);\n      if (d < df) {\n        df = d;\n        qHitF = qHit;\n        idObjF = idObj;\n      }\n    }\n    dHit += df;\n    if (df < 0.001 || dHit > dstFar) break;\n  }\n  if (df >= 0.001) dHit = dstFar;\n  else {\n    qHit = qHitF;\n    idObj = idObjF;\n  }\n  return dHit;\n}\n\nvec3 ObjNf (vec3 p)\n{\n  vec4 v;\n  const vec3 e = vec3 (0.001, -0.001, 0.);\n  v = vec4 (ObjDf (p + e.xxx), ObjDf (p + e.xyy),\n     ObjDf (p + e.yxy), ObjDf (p + e.yyx));\n  return normalize (vec3 (v.x - v.y - v.z - v.w) + 2. * v.yzw);\n}\n\nfloat ObjSShadow (vec3 ro, vec3 rd)\n{\n  float sh, d, h;\n  sh = 1.;\n  d = 0.05;\n  for (int j = 0; j < 16; j ++) {\n    h = ObjDf (ro + rd * d);\n    sh = min (sh, smoothstep (0., 0.05 * d, h));\n    d += 0.1;\n    if (sh < 0.05) break;\n  }\n  return sh;\n}\n\nvec4 FlyerCol ()\n{\n  vec3 qq, col;\n  float spec, br;\n  spec = 1.;\n  qq = qHit / fusLen;\n  br = 0.4 + 0.6 * abs (cos (3. * tCur));\n  col = vec3 (0.9);\n  if (idObj == idFus) {\n    qq.xy = Rot2D (qq.xy, - pi / 4.);\n    if (qq.y > 0.) col *= 0.7;\n  } else if (idObj == idWng) {\n    if (abs (qq.x + 0.05) < 0.115)\n       col *= 1. - SmoothBump (-0.005, 0.005, 0.001, qq.z + 0.17);\n    if (qq.z < -0.17)\n       col *= 1. - SmoothBump (- 0.005, 0.005, 0.001,\n       abs (abs (qq.x + 0.05) - 0.26) - 0.15);\n\n  } else if (idObj == idEngO) {\n    if (qq.z > 0.34) {\n      col = vec3 (0.8, 0.8, 1.);\n    } else if (qq.z < -0.2 && length (qq.xy) < 0.05) {\n      col = vec3 (1., 0.3, 0.);\n      spec = 0.1;\n    }\n  } else if (idObj == idEngI) {\n    if (qq.z > 0.36) col = vec3 (1., 0., 0.);\n    else if (qq.z < 0.) {\n      col = vec3 (1., 0.3, 0.);\n      spec = 0.1;\n    } else {\n      col = vec3 (0.01);\n    }\n  } else if (idObj == idCan) {\n    col *= 0.5;\n  }\n  if (idObj == idFus) {\n    if (qq.z > 0.5) {\n      if (length (qq.xy) < 0.01) {\n        col = vec3 (0., 1., 0.) * br;\n        spec = -1.;\n      } else if (min (abs (qq.x), abs (qq.y)) > 0.01 && abs (qq.z - 0.52) > 0.007) {\n        col = vec3 (0.4, 0.2, 0.1);\n        spec = 0.2;\n      }\n    } else if (qq.z < -1.2 && length (qq.xy) < 0.03) {\n      col = vec3 (1., 0., 0.) * br;\n      spec = -1.;\n    }\n  }\n  return vec4 (col, spec);\n}\n\nfloat FlmAmp (vec3 p, vec3 rd)\n{\n  vec3 dp, q;\n  float g, s, fr, fz;\n  dp = (2. * flmCylRad / 30.) * rd;\n  g = 0.;\n  for (int i = 0; i < 30; i ++) {\n    p += dp;\n    s = length (p.xy);\n    if (s > flmCylRad || g > 10.) break;\n    fr = max (1. - s / flmCylRad, 0.);\n    fz = 0.6 + 0.4 * p.z / flmCylLen;\n    q = 5. * p / fusLen;\n    g += fr * fz * Noisefv3a (vec3 (q.xy, q.z +\n       50. * (1. - 0.5 * fr) * (100. + tCur)));\n  }\n  return min (0.15 * g, 1.);\n}\n\nfloat LsrAmp (vec3 p, vec3 rd)\n{\n  float g;\n  g = smoothstep (0., 0.2, abs (dot (normalize (p.xy), - rd.xy))) *\n     smoothstep (0.3, 0.4, mod (23. * p.z / fusLen - 10. * tCur, 1.)) *\n     step (0.2, mod (0.7 * tCur, 1.));\n  return g;\n}\n\nvec3 ShowScene (vec3 ro, vec3 rd)\n{\n  vec4 objCol;\n  vec3 col, vn, rdm;\n  float dstHit, dstGrnd, dstFlm, aFlm, dstLsr, aLsr, sh;\n  bool isGrnd;\n  flmCylRad = 0.051 * fusLen;\n  flmCylLen = 0.5 * fusLen;\n  flmCylPos = vec3 (0., 0., -0.55 * fusLen - flmCylLen);\n  lsrCylRad = 0.005 * fusLen;\n  lsrCylLen = 5. * fusLen;\n  lsrCylPos = vec3 (0.2 * fusLen, 0., 1.12 * lsrCylLen);\n  dstFlm = FlmRay (ro, rd);\n  dstLsr = LsrRay (ro, rd);\n  dstHit = ObjRay (ro, rd);\n  dstGrnd = GrndRay (ro, rd);\n  if (dstHit < dstFlm) dstFlm = dstFar;\n  if (dstHit < dstLsr) dstLsr = dstFar;\n  isGrnd = false;\n  if (dstHit < dstGrnd) {\n    ro += rd * dstHit;\n    objCol = FlyerCol ();\n    vn = ObjNf (ro);\n    if (objCol.a >= 0.) {\n      sh = 0.1 + 0.9 * ObjSShadow (ro, sunDir);\n      col = objCol.rgb * 0.7 * (0.2 + sh * 0.8 * max (dot (vn, sunDir), 0.)) +\n         0.3 * SkyCol (ro, reflect (rd, vn)) +\n         vec3 (1.) * sh * objCol.a *\n         pow (max (dot (normalize (sunDir - rd), vn), 0.), 256.);\n    } else col = objCol.rgb;\n  } else {\n    dstHit = dstGrnd;\n    if (dstHit < dstFar) {\n      ro += dstGrnd * rd;\n      isGrnd = true;\n    } else col = SkyCol (ro, rd);\n  }\n  if (isGrnd) {\n    vn = VaryNf (5. * ro, GrndNf (ro), 5.);\n    objCol = GrndCol (ro, vn);\n    sh = 0.2 + 0.8 * GrndSShadow (ro, sunDir);\n    col = objCol.rgb * (0.1 + 0.2 * max (vn.y, 0.) +\n       sh * 0.9 * max (dot (vn, sunDir), 0.)) +\n       vec3 (1.) * sh * objCol.a *\n       pow (max (dot (normalize (sunDir - rd), vn), 0.), 256.);\n  }\n  if (dstFlm < min (dstFar, dstHit)) {\n    rdm = (idFlmGrp == 0) ? flyerMat[0] * rd :\n       ((idFlmGrp == 1) ? flyerMat[1] * rd : flyerMat[2] * rd);\n    aFlm = FlmAmp (qHitFlm, rdm);\n    col = mix (col, mix (vec3 (1., 0.2, 0.2),\n       vec3 (1., 1., 0.7), 0.8 * aFlm), aFlm);\n  }\n  if (dstLsr < min (dstFar, dstHit)) {\n    rdm = (idLsrGrp == 0) ? flyerMat[0] * rd :\n       ((idLsrGrp == 1) ? flyerMat[1] * rd : flyerMat[2] * rd);\n    aLsr = LsrAmp (qHitLsr, rdm);\n    col = mix (col, vec3 (1., 0.7, 0.2), aLsr);\n  }\n  if (dstHit < dstFar)\n     col = mix (col, 0.7 * SkyBg (rd), clamp (pow (dstGrnd / dstFar, 4.), 0., 1.));\n   col = pow (clamp (col, 0., 1.), vec3 (0.8));\n  return col;\n}\n\nmat3 EvalOri (vec3 v, vec3 a)\n{\n  vec3 g, w;\n  float f, c, s;\n  v = normalize (v);\n  g = cross (v, vec3 (0., 1., 0.));\n  if (g.y != 0.) {\n    g.y = 0.;\n    w = normalize (cross (g, v));\n  } else w = vec3 (0., 1., 0.);\n  f = v.z * a.x - v.x * a.z;\n  f = - clamp (30. * f, -0.3 * pi, 0.3 * pi);\n  c = cos (f);\n  s = sin (f);\n  return mat3 (c, - s, 0., s, c, 0., 0., 0., 1.) * AxToRMat (v, w);\n}\n\nvoid FlyerPM (float t, float vu)\n{\n  vec3 v, s;\n  t *= vFly;\n  s = sin (trkF * t);\n  flPos = vec3 (dot (trkA, s), 0., t);\n  v = vec3 (dot (trkF * trkA, cos (trkF * t)), 0., 1.);\n  if (vu > 0.) v.xz *= -1.;\n  flMat = EvalOri (v, vec3 (- dot (trkF * trkF * trkA, s), 0., 0.));\n}\n\nvoid mainImage (out vec4 fragColor, in vec2 fragCoord)\n{\nvec4 iMouse = vec4(mX * iResolution.x, mY * iResolution.y, mZ * iResolution.x, mW * iResolution.y);\n\n  mat3 vuMat;\n  vec4 mPtr;\n  vec3 ro, rd;\n  vec2 canvas, uv, ori, ca, sa;\n  float tGap, el, az, zmFac, vuPeriod, dVu, lookDir, t;\n  canvas = iResolution.xy;\n  uv = 2. * fragCoord.xy / canvas - 1.;\n  uv.x *= canvas.x / canvas.y;\n  tCur = iTime;\n  mPtr = iMouse;\n  mPtr.xy = mPtr.xy / canvas - 0.5;\n  tCur += 50.;\n  sunDir = normalize (vec3 (cos (0.031 * tCur), 0.5, sin (0.031 * tCur)));\n  trkF = vec3 (0.029, 0.021, 0.016);\n  trkA = vec3 (15., 23., 34.);\n  fusLen = 1.;\n  vuPeriod = 60.;\n  vFly = 15.;\n  tGap = 16. / vFly;\n  for (int k = 0; k < N_FLYER; k ++) {\n    FlyerPM (tCur + (0.5 + float (k)) * tGap, 0.);\n    flyerPos[k] = flPos;  flyerMat[k] = flMat;\n  }\n  t = mod (tCur / vuPeriod + 0.25, 1.);\n  lookDir = 2. * floor (2. * t) - 1.;\n  dVu = 2. * SmoothBump (0.25, 0.75, 0.1, t) - 1.;\n  FlyerPM (tCur + tGap * 0.5 * float (N_FLYER) * (1. + 0.8 * dVu), lookDir);\n  ro = flPos;\n  ro.y += 0.8 * fusLen + 0.3 * (1. + sin (0.02 * ro.z));\n  az = 0.;\n  el = -0.1 * pi;\n  if (mPtr.z > 0.) {   \n    az = 2. * pi * mPtr.x;\n    el = pi * mPtr.y;\n  }\n  ori = vec2 (el, az);\n  ca = cos (ori);\n  sa = sin (ori);\n  vuMat = mat3 (ca.y, 0., - sa.y, 0., 1., 0., sa.y, 0., ca.y) *\n          mat3 (1., 0., 0., 0., ca.x, - sa.x, 0., sa.x, ca.x);\n  zmFac = 1.5;\n  rd = vuMat * normalize (vec3 (uv, zmFac));\n  rd = rd * flMat;\n  dstFar = 250.;\n  fragColor = vec4 (ShowScene (ro, rd), 1.);\n}\n\nfloat PrCapsDf (vec3 p, float r, float h)\n{\n  return length (p - vec3 (0., 0., h * clamp (p.z / h, -1., 1.))) - r;\n}\n\nfloat PrCylDf (vec3 p, float r, float h)\n{\n  return max (length (p.xy) - r, abs (p.z) - h);\n}\n\nfloat PrFlatCylDf (vec3 p, float rhi, float rlo, float h)\n{\n  return max (length (p.xy - vec2 (rhi *\n     clamp (p.x / rhi, -1., 1.), 0.)) - rlo, abs (p.z) - h);\n}\n\nconst vec4 cHashA4 = vec4 (0., 1., 57., 58.);\nconst vec3 cHashA3 = vec3 (1., 57., 113.);\nconst float cHashM = 43758.54;\n\nvec4 Hashv4f (float p)\n{\n  return fract (sin (p + cHashA4) * cHashM);\n}\n\nfloat Noisefv2 (vec2 p)\n{\n  vec4 t;\n  vec2 ip, fp;\n  ip = floor (p);\n  fp = fract (p);\n  fp = fp * fp * (3. - 2. * fp);\n  t = Hashv4f (dot (ip, cHashA3.xy));\n  return mix (mix (t.x, t.y, fp.x), mix (t.z, t.w, fp.x), fp.y);\n}\n\nvec4 Hashv4v3 (vec3 p)\n{\n  const vec3 cHashVA3 = vec3 (37.1, 61.7, 12.4);\n  const vec3 e = vec3 (1., 0., 0.);\n  return fract (sin (vec4 (dot (p + e.yyy, cHashVA3), dot (p + e.xyy, cHashVA3),\n     dot (p + e.yxy, cHashVA3), dot (p + e.xxy, cHashVA3))) * cHashM);\n}\n\nfloat Noisefv3a (vec3 p)\n{\n  vec3 i, f;\n  i = floor (p);  f = fract (p);\n  f *= f * (3. - 2. * f);\n  vec4 t1 = Hashv4v3 (i);\n  vec4 t2 = Hashv4v3 (i + vec3 (0., 0., 1.));\n  return mix (mix (mix (t1.x, t1.y, f.x), mix (t1.z, t1.w, f.x), f.y),\n              mix (mix (t2.x, t2.y, f.x), mix (t2.z, t2.w, f.x), f.y), f.z);\n}\n\nfloat Fbm3 (vec3 p)\n{\n  const mat3 mr = mat3 (0., 0.8, 0.6, -0.8, 0.36, -0.48, -0.6, -0.48, 0.64);\n  float f, a, am, ap;\n  f = 0.;  a = 0.5;\n  am = 0.5;  ap = 4.;\n  p *= 0.5;\n  for (int i = 0; i < 6; i ++) {\n    f += a * Noisefv3a (p);\n    p *= mr * ap;  a *= am;\n  }\n  return f;\n}\n\nfloat Fbmn (vec3 p, vec3 n)\n{\n  vec3 s;\n  float a;\n  s = vec3 (0.);\n  a = 1.;\n  for (int i = 0; i < 5; i ++) {\n    s += a * vec3 (Noisefv2 (p.yz), Noisefv2 (p.zx), Noisefv2 (p.xy));\n    a *= 0.5;\n    p *= 2.;\n  }\n  return dot (s, abs (n));\n}\n\nvec3 VaryNf (vec3 p, vec3 n, float f)\n{\n  vec3 g;\n  const vec3 e = vec3 (0.1, 0., 0.);\n  g = vec3 (Fbmn (p + e.xyy, n), Fbmn (p + e.yxy, n),\n     Fbmn (p + e.yyx, n)) - Fbmn (p, n);\n  return normalize (n + f * (g - n * dot (n, g)));\n}\n\nmat3 AxToRMat (vec3 vz, vec3 vy)\n{\n  vec3 vx;\n  vx = normalize (cross (vy, vz));\n  vy = cross (vz, vx);\n  return mat3 (vec3 (vx.x, vy.x, vz.x), vec3 (vx.y, vy.y, vz.y),\n     vec3 (vx.z, vy.z, vz.z));\n}\n\nvec2 Rot2D (vec2 q, float a)\n{\n  return q * cos (a) + q.yx * sin (a) * vec2 (-1., 1.);\n}\n\nfloat SmoothMin (float a, float b, float r)\n{\n  float h;\n  h = clamp (0.5 + 0.5 * (b - a) / r, 0., 1.);\n  return mix (b, a, h) - r * h * (1. - h);\n}\n\nfloat SmoothMax (float a, float b, float r)\n{\n  return - SmoothMin (- a, - b, r);\n}\n\nfloat SmoothBump (float lo, float hi, float w, float x)\n{\n  return (1. - smoothstep (hi - w, hi + w, x)) * smoothstep (lo - w, lo + w, x);\n}\n",
  "meta": {
    "name": "Red Canyon 2",
    "author": "dr2",
    "version": 0.1,
    "uniforms": {},
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false,
    "originalName": "Red Canyon 2",
    "alpha": 1,
    "enabled": false,
    "compositeOperation": "normal"
  }
};

/***/ })
/******/ ]);