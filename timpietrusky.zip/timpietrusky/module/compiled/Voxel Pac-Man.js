/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {
    "mX": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse X"
    },
    "mY": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Y"
    },
    "mZ": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Z"
    },
    "mW": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse W"
    }
  },
  "fragmentShader": "uniform float mX;\nuniform float mY;\nuniform float mZ;\nuniform float mW;\n///////////////////////////////////////////////////////////////////////////////\n//                                                                           //\n//  GGGG IIIII  AAA  N   N TTTTT     PPPP   AAA   CCCC     M   M  AAA  N   N //\n// G       I   A   A NN  N   T       P   P A   A C         MM MM A   A NN  N //\n// G  GG   I   AAAAA N N N   T       PPPP  AAAAA C     --- M M M AAAAA N N N //\n// G   G   I   A   A N  NN   T       P     A   A C         M   M A   A N  NN //\n//  GGGG IIIII A   A N   N   T       P     A   A  CCCC     M   M A   A N   N //\n//                                                                           //\n///////////////////////////////////////////////////////////////////////////////\n\n// Parameters\n#define VOXEL_RESOLUTION\t1.5\n#define VOXEL_LIGHTING\n#define SHADOW\n#define GROUND\n#define GHOST\n#define MOUSE\n#define HSV2RGB_FAST\n\n#define CAMERA_FOCAL_LENGTH\t8.0\n#define DELTA\t\t\t\t0.01\n#define RAY_LENGTH_MAX\t\t500.0\n#define RAY_STEP_MAX\t\t100.0\n#define AMBIENT\t\t\t\t0.2\n#define SPECULAR_POWER\t\t2.0\n#define SPECULAR_INTENSITY\t0.3\n#define SHADOW_LENGTH\t\t150.0\n#define SHADOW_POWER\t\t3.0\n#define FADE_POWER\t\t\t1.0\n#define BACKGROUND\t\t\t0.7\n#define GLOW\t\t\t\t0.4\n#define GAMMA\t\t\t\t0.8\n\n// Math constants\n#define PI\t\t3.14159265359\n#define SQRT3\t1.73205080757\n\n// Global variable to handle the glow effect\nfloat glowCounter;\n\n// PRNG (from https://www.shadertoy.com/view/4djSRW)\nfloat rand (in vec3 seed) {\n\tseed = fract (seed * vec3 (5.3983, 5.4427, 6.9371));\n\tseed += dot (seed.yzx, seed.xyz + vec3 (21.5351, 14.3137, 15.3219));\n\treturn fract (seed.x * seed.y * seed.z * 95.4337);\n}\n\n// Distance to the voxel\nfloat distVoxel (in vec3 p) {\n\n\t// Update the glow counter\n\t++glowCounter;\n\n\t// Rounded box\n\tconst float voxelRadius = 0.25;\n\treturn length (max (abs (p) - 0.5 + voxelRadius, 0.0)) - voxelRadius;\n}\n\n// Distance to the scene and color of the closest point\nvec2 distScene (in vec3 p, out vec3 P) {\n\n\t// Update the glow counter\n\t++glowCounter;\n\n\t// Scaling\n\tp *= VOXEL_RESOLUTION;\n\n\t// Velocity, period of the waves, spacing of the gums\n\tfloat v = VOXEL_RESOLUTION * floor (iTime * 100.0 / VOXEL_RESOLUTION);\n\tconst float k1 = 0.05;\n\tconst float k2 = 60.0;\n\n\t// Giant Pac-Man\n\tfloat body = length (p);\n\tbody = max (body - 32.0, 27.0 - body);\n\tfloat eyes = 6.0 - length (vec3 (abs (p.x) - 12.5, p.y - 19.5, p.z - 20.0));\n\tfloat mouthAngle = PI * (0.07 + 0.07 * cos (2.0 * v * PI / k2));\n\tfloat mouthTop = dot (p, vec3 (0.0, -cos (mouthAngle), sin (mouthAngle))) - 2.0;\n\tmouthAngle *= 2.5;\n\tfloat mouthBottom = dot (p, vec3 (0.0, cos (mouthAngle), sin (mouthAngle)));\n\tfloat pacMan = max (max (body, eyes), min (mouthTop, mouthBottom));\n\tvec2 d = vec2 (pacMan, 0.13);\n\tP = p;\n\n\t// Gums\n\tvec3 q = vec3 (p.xy, mod (p.z + v, k2) - k2 * 0.5);\n\tfloat gum = max (length (q) - 6.0, -p.z);\n\tif (gum < d.x) {\n\t\td = vec2 (gum, 0.35);\n\t\tP = q;\n\t}\n\n\t// Ground\n\t#ifdef GROUND\n\tq = vec3 (p.xy, p.z + v);\n\tfloat ground = (q.y + 50.0 + 14.0 * cos (q.x * k1) * cos (q.z * k1)) * 0.7;\n\tif (ground < d.x) {\n\t\td = vec2 (ground, 0.55);\n\t\tP = q;\n\t}\n\t#endif\n\n\t// Ghost\n\t#ifdef GHOST\n\tv = VOXEL_RESOLUTION * floor ((130.0 + 60.0 * cos (iTime * 3.0)) / VOXEL_RESOLUTION);\n\tq = vec3 (p.xy, p.z + v);\n\tbody = length (vec3 (q.x, max (q.y - 4.0, 0.0), q.z));\n\tbody = max (body - 28.0, 22.0 - body);\n\teyes = 8.0 - length (vec3 (abs (q.x) - 12.0, q.y - 10.0, q.z - 22.0));\n\tfloat bottom = (q.y + 28.0 + 4.0 * cos (p.x * 0.4) * cos (p.z * 0.4)) * 0.7;\n\tfloat ghost = max (max (body, eyes), -bottom);\n\tif (ghost < d.x) {\n\t\td = vec2 (ghost, 0.76);\n\t\tP = q;\n\t}\n\t#endif\n\n\t// Scaling\n\td.x /= VOXEL_RESOLUTION;\n\treturn d;\n}\n\n// Distance to the (voxelized?) scene\nvec4 dist (inout vec3 p, in vec3 ray, in float voxelized, in float rayLengthMax) {\n\tvec3 P = p;\n\tvec2 d = vec2 (1.0 / 0.0, 0.0);\n\tfloat rayLength = 0.0;\n\tfloat rayLengthInVoxel = 0.0;\n\tfloat rayLengthCheckVoxel = 0.0;\n\tvec3 raySign = sign (ray);\n\tvec3 rayDeltaVoxel = raySign / ray;\n\tfor (float rayStep = 0.0; rayStep < RAY_STEP_MAX; ++rayStep) {\n\t\tif (rayLength < rayLengthInVoxel) {\n\t\t\td.x = distVoxel (fract (p + 0.5) - 0.5);\n\t\t\tif (d.x < DELTA) {\n\t\t\t\tbreak;\n\t\t\t}\n\t\t} else if (rayLength < rayLengthCheckVoxel) {\n\t\t\tvec3 rayDelta = (0.5 - raySign * (fract (p + 0.5) - 0.5)) * rayDeltaVoxel;\n\t\t\tfloat dNext = min (rayDelta.x, min (rayDelta.y, rayDelta.z));\n\t\t\td = distScene (floor (p + 0.5), P);\n\t\t\tif (d.x < 0.0) {\n\t\t\t\trayDelta = rayDeltaVoxel - rayDelta;\n\t\t\t\td.x = max (rayLengthInVoxel - rayLength, DELTA - min (rayDelta.x, min (rayDelta.y, rayDelta.z)));\n\t\t\t\trayLengthInVoxel = rayLength + dNext;\n\t\t\t} else {\n\t\t\t\td.x = DELTA + dNext;\n\t\t\t}\n\t\t} else {\n\t\t\td = distScene (p, P);\n\t\t\tif (voxelized > 0.5) {\n\t\t\t\tif (d.x < SQRT3 * 0.5) {\n\t\t\t\t\trayLengthCheckVoxel = rayLength + abs (d.x) + SQRT3 * 0.5;\n\t\t\t\t\td.x = max (rayLengthInVoxel - rayLength + DELTA, d.x - SQRT3 * 0.5);\n\t\t\t\t}\n\t\t\t} else if (d.x < DELTA) {\n\t\t\t\tbreak;\n\t\t\t}\n\t\t}\n\t\trayLength += d.x;\n\t\tif (rayLength > rayLengthMax) {\n\t\t\tbreak;\n\t\t}\n\t\tp += d.x * ray;\n\t}\n\treturn vec4 (d, rayLength, rand (P));\n}\n\n// Normal at a given point\nvec3 normal (in vec3 p, in float voxelized) {\n\tvec2 h = vec2 (DELTA, -DELTA);\n\tvec3 n;\n\tif (voxelized > 0.5) {\n\t\tp = fract (p + 0.5) - 0.5;\n\t\tn = h.xxx * distVoxel (p + h.xxx) +\n\t\t\th.xyy * distVoxel (p + h.xyy) +\n\t\t\th.yxy * distVoxel (p + h.yxy) +\n\t\t\th.yyx * distVoxel (p + h.yyx);\n\t} else {\n\t\tn = h.xxx * distScene (p + h.xxx, n).x +\n\t\t\th.xyy * distScene (p + h.xyy, n).x +\n\t\t\th.yxy * distScene (p + h.yxy, n).x +\n\t\t\th.yyx * distScene (p + h.yyx, n).x;\n\t}\n\treturn normalize (n);\n}\n\n// HSV to RGB\nvec3 hsv2rgb (in vec3 hsv) {\n\t#ifdef HSV2RGB_SAFE\n\thsv.yz = clamp (hsv.yz, 0.0, 1.0);\n\t#endif\n\t#ifdef HSV2RGB_FAST\n\treturn hsv.z * (1.0 + 0.5 * hsv.y * (cos (2.0 * PI * (hsv.x + vec3 (0.0, 2.0 / 3.0, 1.0 / 3.0))) - 1.0));\n\t#else\n\treturn hsv.z * (1.0 + hsv.y * clamp (abs (fract (hsv.x + vec3 (0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 2.0, -1.0, 0.0));\n\t#endif\n}\n\n// Main function\nvoid mainImage (out vec4 fragColor, in vec2 fragCoord) {\nvec4 iMouse = vec4(mX * iResolution.x, mY * iResolution.y, mZ * iResolution.x, mW * iResolution.y);\n\n\n\t// Get the fragment\n\tvec2 frag = (2.0 * fragCoord.xy - iResolution.xy) / iResolution.y;\n\n\t// Define the rendering mode\n\tfloat modeTiming = iTime * 0.234;\n\tfloat modeAngle = PI * cos (iTime * 0.2);\n\tmodeAngle = dot (frag - vec2 (cos (iTime * 2.0), 0.0), vec2 (cos (modeAngle), sin (modeAngle)));\n\tfloat modeVoxel = step (0.5, fract (modeTiming / (4.0 * PI)));\n\tmodeTiming = cos (modeTiming);\n\tfloat mode3D = smoothstep (0.8, 0.5, modeTiming);\n\tfloat modeSwitch = smoothstep (0.995, 1.0, modeTiming) + smoothstep (0.02, 0.0, abs (modeAngle)) * modeVoxel;\n\tmodeVoxel = 1.0 + (step (0.0, modeAngle) - 1.0) * modeVoxel;\n\n\t// Define the ray corresponding to this fragment\n\tvec3 ray = normalize (vec3 (frag, mix (8.0, CAMERA_FOCAL_LENGTH, mode3D)));\n\n\t// Compute the orientation of the camera\n\tfloat yawAngle = PI * (1.2 + 0.2 * cos (iTime * 0.5));\n\tfloat pitchAngle = PI * (0.1 * cos (iTime * 0.3) - 0.05);\n\t#ifdef MOUSE\n\tyawAngle += 4.0 * PI * iMouse.x / iResolution.x;\n\tpitchAngle += PI * 0.3 * (1.0 - iMouse.y / iResolution.y);\n\t#endif\n\tyawAngle = mix (PI * 1.5, yawAngle, mode3D);\n\tpitchAngle *= mode3D;\n\n\tfloat cosYaw = cos (yawAngle);\n\tfloat sinYaw = sin (yawAngle);\n\tfloat cosPitch = cos (pitchAngle);\n\tfloat sinPitch = sin (pitchAngle);\n\n\tmat3 cameraOrientation;\n\tcameraOrientation [0] = vec3 (cosYaw, 0.0, -sinYaw);\n\tcameraOrientation [1] = vec3 (sinYaw * sinPitch, cosPitch, cosYaw * sinPitch);\n\tcameraOrientation [2] = vec3 (sinYaw * cosPitch, -sinPitch, cosYaw * cosPitch);\n\n\tray = cameraOrientation * ray;\n\n\t// Compute the origin of the ray\n\tfloat cameraDist = mix (300.0, 195.0 + 150.0 * cos (iTime * 0.8), mode3D);\n\tvec3 origin = (vec3 (0.0, 0.0, 40.0 * sin (iTime * 0.2)) - cameraOrientation [2] * cameraDist) / VOXEL_RESOLUTION;\n\n\t// Compute the distance to the scene\n\tglowCounter = 0.0;\n\tvec4 d = dist (origin, ray, modeVoxel, RAY_LENGTH_MAX / VOXEL_RESOLUTION);\n\n\t// Set the background color\n\tvec3 finalColor = hsv2rgb (vec3 (0.2 * ray.y + 0.4 * modeVoxel - 0.37, 1.0, mode3D * BACKGROUND));\n\tvec3 glowColor = GLOW * vec3 (1.0, 0.3, 0.0) * glowCounter / RAY_STEP_MAX;\n\tif (d.x < DELTA) {\n\n\t\t// Set the object color\n\t\tvec3 color = hsv2rgb (vec3 (d.y + 0.1 * d.w * modeVoxel, 0.5 + 0.5 * modeVoxel, 1.0));\n\n\t\t// Lighting\n\t\tvec3 l = normalize (mix (vec3 (1.0, 0.0, 0.0), vec3 (1.25 + cos (iTime * 0.2), 1.0, 1.0), mode3D));\n\t\t#ifdef VOXEL_LIGHTING\n\t\tif (modeVoxel > 0.5) {\n\t\t\tvec3 n = normal (floor (origin + 0.5), 0.0);\n\t\t\tfloat diffuse = max (0.0, dot (n, l));\n\t\t\tfloat specular = pow (max (0.0, dot (reflect (ray, n), l)), SPECULAR_POWER) * SPECULAR_INTENSITY;\n\t\t\tcolor = (AMBIENT + diffuse) * color + specular;\n\t\t}\n\t\t#endif\n\t\tvec3 n = normal (origin, modeVoxel);\n\t\tfloat diffuse = dot (n, l);\n\t\tfloat specular;\n\t\tif (diffuse < 0.0) {\n\t\t\tdiffuse = 0.0;\n\t\t\tspecular = 0.0;\n\t\t} else {\n\t\t\tspecular = pow (max (0.0, dot (reflect (ray, n), l)), SPECULAR_POWER) * SPECULAR_INTENSITY;\n\t\t\t#ifdef SHADOW\n\t\t\torigin += n * DELTA * 2.0;\n\t\t\tvec4 shadow = dist (origin, l, modeVoxel, SHADOW_LENGTH / VOXEL_RESOLUTION);\n\t\t\tif (shadow.x < DELTA) {\n\t\t\t\tshadow.z = pow (min (1.0, shadow.z * VOXEL_RESOLUTION / SHADOW_LENGTH), SHADOW_POWER);\n\t\t\t\tdiffuse *= shadow.z;\n\t\t\t\tspecular *= shadow.z;\n\t\t\t}\n\t\t\t#endif\n\t\t}\n\t\tcolor = (AMBIENT + diffuse) * color + specular;\n\n\t\t// Fading\n\t\tfloat fade = pow (max (0.0, 1.0 - d.z * VOXEL_RESOLUTION / RAY_LENGTH_MAX), FADE_POWER);\n\t\tfinalColor = mix (finalColor, color, fade);\n\t}\n\n\t// Set the fragment color\n\tfinalColor = mix (pow (finalColor, vec3 (GAMMA)) + glowColor, vec3 (1.0), modeSwitch);\n\tfragColor = vec4 (finalColor, 1.0);\n}",
  "meta": {
    "name": "Voxel Pac-Man",
    "author": "Nrx",
    "version": 0.1,
    "uniforms": {},
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false,
    "originalName": "Voxel Pac-Man",
    "alpha": 1,
    "enabled": false,
    "compositeOperation": "normal"
  }
};

/***/ })
/******/ ]);