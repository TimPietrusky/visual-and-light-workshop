/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {
    "modvxy": {
      "type": "float",
      "default": 0.05,
      "label": "XY",
      "min": 0.0,
      "max": 5.0
    },
    "modvamount": {
      "type": "float",
      "default": 0.0,
      "label": "Amount",
      "min": 0.0,
      "max": 35.0
    },
    "modvdepth": {
      "type": "float",
      "default": 3.7,
      "label": "Depth",
      "min": 0.0,
      "max": 10.0
    },
    "mX": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse X"
    },
    "mY": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Y"
    },
    "mZ": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Z"
    },
    "mW": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse W"
    }
  },
  "fragmentShader": "uniform float modvxy;\n    uniform float modvamount;\n    uniform float modvdepth;\n    \n    mat2 rotate(float a)\n    {\n        return mat2(cos(a), sin(a), -sin(a), cos(a));\n    }\n    \n    float pattern(vec2 p)\n    {\n        p *= modvamount;\n        return abs(sin(p.x) + sin(p.y));\n    }\n    \n    float boxmap(vec3 p)\n    {\n        p *= 0.3;\n        vec3 m = pow(abs(normalize(p)), vec3(20));\n        vec3 a = vec3(pattern(p.yz),pattern(p.zx),pattern(p.xy));\n      return dot(a,m)/(m.x+m.y+m.z);\n    }\n    \n    vec3 smin(vec3 a, vec3 b)\n    {\n        float k = 0.08;\n      vec3 h = clamp( 0.5 + 0.5*(b-a)/k, 0.0, 1.0 );\n      return mix( b, a, h ) - k*h*(1.0-h);\n    }\n    \n    vec3 sabs(vec3 p)\n    {\n       return  p - 2.0 * smin(vec3(0), p); \n    }\n    \n    float map(in vec3 p)\n    {  \n        float s = modvdepth;\n        float amp = 1.0/s;\n        float c = 0.5;\n        p = sabs(mod(p, c * 2.0) - c); \n        float de = 100.;\n        for(int i=0; i<3; i++){\n            p.xy *= rotate(0.4+sin(iTime*0.2+ 0.3*sin(iTime*0.4))*0.2);\n            p.yz *= rotate(0.4+sin(iTime*0.3+ 0.5*sin(iTime*0.5))*0.2);\n            p = sabs(p); \n            p *= s;\n            p -= vec3(0.2*p.z, 0.6*p.x, 0.4) * (s - 1.0);\n          de = abs(length(p*amp) - 0.2) ;\n            amp /= s;\n        }   \n        return de + boxmap(p) * 0.02 - 0.01;\n    }\n    \n    vec3 calcNormal(vec3 p){\n      vec2 e = vec2(1, -1) * 0.001;\n      return normalize(\n        e.xyy*map(p+e.xyy)+e.yyx*map(p+e.yyx)+ \n        e.yxy*map(p+e.yxy)+e.xxx*map(p+e.xxx)\n      );\n    }\n    \n    vec3 doColor(vec3 p){\n      return vec3(0.2,0.9,0.2) * boxmap(p);\n    }\n    \n    void mainImage( out vec4 fragColor, in vec2 fragCoord )\n    {\n        vec2 p = (fragCoord * 2.0 - iResolution.xy) / iResolution.y;\n        vec3 ro = vec3(0.2, 0.1, 0.5)+iTime*0.1;\n        vec3 rd = normalize(vec3(p, 2));\n        \n        \n        \n        rd.xz *= rotate(sin(iTime*0.7)*0.6);\n        rd.yz *= rotate(sin(iTime*0.2)*0.6);\n        rd.xy *= rotate(sin(iTime*modvxy));   \n        vec3 col = mix(\n            vec3(0.3, 0.7, 0.8),\n            vec3(0.1, 0.1, 0.2),\n            smoothstep(0.3, 2.5, length(p)));    \n        float t = 0.1, d;\n       for(int i = 0; i < 300; i++)\n        {\n            d = map(ro + rd * t);\n          t += 0.1 * d;\n          if(d < 0.001 || t > 5.0) break;\n        }\n        if(d < 0.001)\n        {\n          vec3 p = ro + rd * t;\n         vec3 nor = calcNormal(p);\n          vec3 li = normalize(vec3(1));\n            vec3 c = doColor(p);\n            c *= clamp(dot(nor, li), 0.3, 1.0);\n            c *= max(0.5 + 0.5 * nor.y, 0.0);\n            c += pow(clamp(dot(reflect(normalize(p - ro), nor), li), 0.0, 1.0), 20.0);\n            c.x +=1.0- exp(-t*t*0.15);\n            c = clamp(c,0.0,1.0);\n            col = mix(col,c,exp(-t*t*0.6));\n        }\n        col = pow(col, vec3(0.8));\n        col= mix(col, vec3(col.x), clamp(sin(iTime*0.5 + sin(iTime*0.2)*0.5)*2.0-1.0, 0.0, 1.0));\n        fragColor = vec4(col, 1.0);\n    }",
  "meta": {
    "name": "Jungle",
    "author": "gaz",
    "version": 0.1,
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false
  }
};

/***/ })
/******/ ]);