/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {},
  "fragmentShader": "// Created by Reinder Nijhoff 2014\n// @reindernijhoff\n//\n// https://www.shadertoy.com/view/Xtf3zn\n//\n// car model is made by Eiffie\n// shader 'Shiny Toy': https://www.shadertoy.com/view/ldsGWB\n\n#define BUMPMAP\n#define MARCHSTEPS 128\n#define MARCHSTEPSREFLECTION 48\n#define LIGHTINTENSITY 5.\n\n//----------------------------------------------------------------------\n\nconst vec3 backgroundColor = vec3(0.2,0.4,0.6) * 0.09;\n#define time (iTime + 90.)\n\n//----------------------------------------------------------------------\n// noises\n\nfloat hash( float n ) {\n    return fract(sin(n)*687.3123);\n}\n\nfloat noise( in vec2 x ) {\n    vec2 p = floor(x);\n    vec2 f = fract(x);\n    f = f*f*(3.0-2.0*f);\n    float n = p.x + p.y*157.0;\n    return mix(mix( hash(n+  0.0), hash(n+  1.0),f.x),\n               mix( hash(n+157.0), hash(n+158.0),f.x),f.y);\n}\n\nconst mat2 m2 = mat2( 0.80, -0.60, 0.60, 0.80 );\n\nfloat fbm( vec2 p ) {\n    float f = 0.0;\n    f += 0.5000*noise( p ); p = m2*p*2.02;\n    f += 0.2500*noise( p ); p = m2*p*2.03;\n    f += 0.1250*noise( p ); p = m2*p*2.01;\n//    f += 0.0625*noise( p );\n    \n    return f/0.9375;\n}\n\n//----------------------------------------------------------------------\n// distance primitives\n\nfloat udRoundBox( vec3 p, vec3 b, float r ) {\n  return length(max(abs(p)-b,0.0))-r;\n}\n\nfloat sdBox( in vec3 p, in vec3 b ) {\n    vec3 d = abs(p) - b;\n    return min(max(d.x,max(d.y,d.z)),0.0) + length(max(d,0.0));\n}\n\nfloat sdSphere( in vec3 p, in float s ) {\n    return length(p)-s;\n}\n\nfloat sdCylinder( in vec3 p, in vec2 h ) {\n    vec2 d = abs(vec2(length(p.xz),p.y)) - h;\n    return min(max(d.x,d.y),0.0) + length(max(d,0.0));\n}\n\n//----------------------------------------------------------------------\n// distance operators\n\nfloat opU( float d2, float d1 ) { return min( d1,d2); }\nfloat opS( float d2, float d1 ) { return max(-d1,d2); }\nfloat smin( float a, float b, float k ) { return -log(exp(-k*a)+exp(-k*b))/k; } //from iq\n\n//----------------------------------------------------------------------\n// Map functions\n\n// car model is made by Eiffie\n// shader 'Shiny Toy': https://www.shadertoy.com/view/ldsGWB\n\nfloat mapCar(in vec3 p0){ \n\tvec3 p=p0+vec3(0.0,1.24,0.0);\n\tfloat r=length(p.yz);\n\tfloat d= length(max(vec3(abs(p.x)-0.35,r-1.92,-p.y+1.4),0.0))-0.05;\n\td=max(d,p.z-1.0);\n\tp=p0+vec3(0.0,-0.22,0.39);\n\tp.xz=abs(p.xz)-vec2(0.5300,0.9600);p.x=abs(p.x);\n\tr=length(p.yz);\n\td=smin(d,length(max(vec3(p.x-0.08,r-0.25,-p.y-0.08),0.0))-0.04,8.0);\n\td=max(d,-max(p.x-0.165,r-0.24));\n\tfloat d2=length(vec2(max(p.x-0.13,0.0),r-0.2))-0.02;\n\td=min(d,d2);\n\n\treturn d;\n}\n\nfloat dL; // minimal distance to light\n\nfloat map( const in vec3 p ) {\n\tvec3 pd = p;\n    float d;\n    \n    pd.x = abs( pd.x );\n    pd.z *= -sign( p.x );\n    \n    float ch = hash( floor( (pd.z+18.*time)/40. ) );\n    float lh = hash( floor( pd.z/13. ) );\n    \n    vec3 pdm = vec3( pd.x, pd.y, mod( pd.z, 10.) - 5. );\n    dL = sdSphere( vec3(pdm.x-8.1,pdm.y-4.5,pdm.z), 0.1 );\n    \n    dL = opU( dL, sdBox( vec3(pdm.x-12., pdm.y-9.5-lh,  mod( pd.z, 91.) - 45.5 ), vec3(0.2,4.5, 0.2) ) );\n    dL = opU( dL, sdBox( vec3(pdm.x-12., pdm.y-11.5+lh, mod( pd.z, 31.) - 15.5 ), vec3(0.22,5.5, 0.2) ) );\n    dL = opU( dL, sdBox( vec3(pdm.x-12., pdm.y-8.5-lh,  mod( pd.z, 41.) - 20.5 ), vec3(0.24,3.5, 0.2) ) );\n   \n    if( lh > 0.5 ) {\n\t    dL = opU( dL, sdBox( vec3(pdm.x-12.5,pdm.y-2.75-lh,  mod( pd.z, 13.) - 6.5 ), vec3(0.1,0.25, 3.2) ) );\n    }\n    \n    vec3 pm = vec3( mod( pd.x + floor( pd.z * 4. )*0.25, 0.5 ) - 0.25, pd.y, mod( pd.z, 0.25 ) - 0.125 );\n\td = udRoundBox( pm, vec3( 0.245,0.1, 0.12 ), 0.005 ); \n    \n    d = opS( d, -(p.x+8.) );\n    d = opU( d, pd.y );\n\n    vec3 pdc = vec3( pd.x, pd.y, mod( pd.z+18.*time, 40.) - 20. );\n    \n    // car\n    if( ch > 0.75 ) {\n        pdc.x += (ch-0.75)*4.;\n\t    dL = opU( dL, sdSphere( vec3( abs(pdc.x-5.)-1.05, pdc.y-0.55, pdc.z ),    0.025 ) );\n\t    dL = opU( dL, sdSphere( vec3( abs(pdc.x-5.)-1.2,  pdc.y-0.65,  pdc.z+6.05 ), 0.025 ) );\n\n        d = opU( d,  mapCar( (pdc-vec3(5.,-0.025,-2.3))*0.45 ) );\n \t}\n    \n    d = opU( d, 13.-pd.x );\n    d = opU( d, sdCylinder( vec3(pdm.x-8.5, pdm.y, pdm.z), vec2(0.075,4.5)) );\n    d = opU( d, dL );\n    \n\treturn d;\n}\n\n//----------------------------------------------------------------------\n\nvec3 calcNormalSimple( in vec3 pos ) {   \n    const vec2 e = vec2(1.0,-1.0)*0.005;\n\n    vec3 n = normalize( e.xyy*map( pos + e.xyy ) + \n\t\t\t\t\t    e.yyx*map( pos + e.yyx )   + \n\t\t\t\t\t    e.yxy*map( pos + e.yxy )   + \n\t\t\t\t\t    e.xxx*map( pos + e.xxx )   );  \n    return n;\n}\n\nvec3 calcNormal( in vec3 pos ) {\n    vec3 n = calcNormalSimple( pos );\n    if( pos.y > 0.12 ) return n;\n\n#ifdef BUMPMAP\n    vec2 oc = floor( vec2(pos.x+floor( pos.z * 4. )*0.25, pos.z) * vec2( 2., 4. ) );\n\n    if( abs(pos.x)<8. ) {\n\t\toc = pos.xz;\n    }\n    \n     vec3 p = pos * 250.;\n   \t vec3 xn = 0.05*vec3(noise(p.xz)-0.5,0.,noise(p.zx)-0.5);\n     xn += 0.1*vec3(fbm(oc.xy)-0.5,0.,fbm(oc.yx)-0.5);\n    \n    n = normalize( xn + n );\n#endif\n    \n    return n;\n}\n\nvec3 int1, int2, nor1;\nvec4 lint1, lint2;\n\nfloat intersect( in vec3 ro, in vec3 rd ) {\n\tconst float precis = 0.001;\n    float h = precis*2.0;\n    float t = 0.;\n    int1 = int2 = vec3( -500. );\n    lint1 = lint2 = vec4( -500. );\n    float mld = 100.;\n    \n\tfor( int i=0; i < MARCHSTEPS; i++ ) {\n        h = map( ro+rd*t );\n\t\tif(dL < mld){\n\t\t\tmld=dL;\n            lint1.xyz = ro+rd*t;\n\t\t\tlint1.w = abs(dL);\n\t\t}\n        if( h < precis ) {\n            int1.xyz = ro+rd*t;\n            break;\n        } \n        t += max(h, precis*2.);\n    }\n    \n    if( int1.z < -400. || t > 300.) {\n        // check intersection with plane y = -0.1;\n        float d = -(ro.y + 0.1)/rd.y;\n\t\tif( d > 0. ) {\n\t\t\tint1.xyz = ro+rd*d;\n\t    } else {\n        \treturn -1.;\n    \t}\n    }\n    \n    ro = ro + rd*t;\n    nor1 = calcNormal(ro);\n    ro += 0.01*nor1;\n    rd = reflect( rd, nor1 );\n    t = 0.0;\n    h = precis*2.0;\n    mld = 100.;\n    \n    for( int i=0; i < MARCHSTEPSREFLECTION; i++ ) {\n        h = map( ro+rd*t );\n\t\tif(dL < mld){\n\t\t\tmld=dL;            \n            lint2.xyz = ro+rd*t;\n\t\t\tlint2.w = abs(dL);\n\t\t}\n        if( h < precis ) {\n   \t\t\tint2.xyz = ro+rd*t;\n            return 1.;\n        }   \n        t += max(h, precis*2.);\n    }\n\n    return 0.;\n}\n\n//----------------------------------------------------------------------\n// shade\n\nvec3 shade( in vec3 ro, in vec3 pos, in vec3 nor ) {\n    vec3  col = vec3(0.5);\n    \n    if( abs(pos.x) > 15. || abs(pos.x) < 8. ) col = vec3( 0.02 );\n    if( pos.y < 0.01 ) {\n        if( abs( int1.x ) < 0.1 ) col = vec3( 0.9 );\n        if( abs( abs( int1.x )-7.4 ) < 0.1 ) col = vec3( 0.9 );\n    }    \n    \n    float sh = clamp( dot( nor, normalize( vec3( -0.3, 0.3, -0.5 ) ) ), 0., 1.);\n  \tcol *= (sh * backgroundColor);  \n \n    if( abs( pos.x ) > 12.9 && pos.y > 9.) { // windows\n        float ha = hash(  133.1234*floor( pos.y / 3. ) + floor( (pos.z) / 3. ) );\n        if( ha > 0.95) {\n            col = ( (ha-0.95)*10.) * vec3( 1., 0.7, 0.4 );\n        }\n    }\n    \n\tcol = mix(  backgroundColor, col, exp( min(max(0.1*pos.y,0.25)-0.065*distance(pos, ro),0.) ) );\n  \n    return col;\n}\n\nvec3 getLightColor( in vec3 pos ) {\n    vec3 lcol = vec3( 1., .7, .5 );\n    \n\tvec3 pd = pos;\n    pd.x = abs( pd.x );\n    pd.z *= -sign( pos.x );\n    \n    float ch = hash( floor( (pd.z+18.*time)/40. ) );\n    vec3 pdc = vec3( pd.x, pd.y, mod( pd.z+18.*time, 40.) - 20. );\n\n    if( ch > 0.75 ) { // car\n        pdc.x += (ch-0.75)*4.;\n        if(  sdSphere( vec3( abs(pdc.x-5.)-1.05, pdc.y-0.55, pdc.z ), 0.25) < 2. ) {\n            lcol = vec3( 1., 0.05, 0.01 );\n        }\n    }\n    if( pd.y > 2. && abs(pd.x) > 10. && pd.y < 5. ) {\n        float fl = floor( pd.z/13. );\n        lcol = 0.4*lcol+0.5*vec3( hash( .1562+fl ), hash( .423134+fl ), 0. );\n    }\n    if(  abs(pd.x) > 10. && pd.y > 5. ) {\n        float fl = floor( pd.z/2. );\n        lcol = 0.5*lcol+0.5*vec3( hash( .1562+fl ),  hash( .923134+fl ), hash( .423134+fl ) );\n    }\n   \n    return lcol;\n}\n\nfloat randomStart(vec2 co){return 0.8+0.2*hash(dot(co,vec2(123.42,117.853))*412.453);}\n\n//----------------------------------------------------------------------\n// main\n\nvoid mainImage( out vec4 fragColor, in vec2 fragCoord ) {    \n    vec2 q = fragCoord.xy / iResolution.xy;\n\tvec2 p = -1.0 + 2.0*q;\n\tp.x *= iResolution.x / iResolution.y;\n        \n    if (q.y < .12 || q.y >= .88) {\n\t\tfragColor=vec4(0.,0.,0.,1.);\n\t\treturn;\n    } else {\n    \n        // camera\n        float z = time;\n        float x = -10.9+1.*sin(time*0.2);\n        vec3 ro = vec3(x,  1.3+.3*cos(time*0.26), z-1.);\n        vec3 ta = vec3(-8.,1.3+.4*cos(time*0.26), z+4.+cos(time*0.04));\n\n        vec3 ww = normalize( ta - ro );\n        vec3 uu = normalize( cross(ww,vec3(0.0,1.0,0.0) ) );\n        vec3 vv = normalize( cross(uu,ww));\n        vec3 rd = normalize( -p.x*uu + p.y*vv + 2.2*ww );\n\n        vec3 col = backgroundColor;\n\n        // raymarch\n        float ints = intersect(ro+randomStart(p)*rd ,rd );\n        if(  ints > -0.5 ) {\n\n            // calculate reflectance\n            float r = 0.09;     \t        \n            if( int1.y > 0.129 ) r = 0.025 * hash(  133.1234*floor( int1.y / 3. ) + floor( int1.z / 3. ) );\n            if( abs(int1.x) < 8. ) {\n                if( int1.y < 0.01 ) { // road\n                    r = 0.007*fbm(int1.xz);\n                } else { // car\n                    r = 0.02;\n                }\n            }\n            if( abs( int1.x ) < 0.1 ) r *= 4.;\n            if( abs( abs( int1.x )-7.4 ) < 0.1 ) r *= 4.;\n\n            r *= 2.;\n\n            col = shade( ro, int1.xyz, nor1 );\n\n            if( ints > 0.5 ) {\n                col += r * shade( int1.xyz, int2.xyz, calcNormalSimple(int2.xyz) );\n            }  \n            if( lint2.w > 0. ) {            \n                col += (r*LIGHTINTENSITY*exp(-lint2.w*7.0)) * getLightColor(lint2.xyz);\n            } \n        } \n\n        // Rain (by Dave Hoskins)\n        vec2 st = 256. * ( p* vec2(.5, .01)+vec2(time*.13-q.y*.6, time*.13) );\n        float f = noise( st ) * noise( st*0.773) * 1.55;\n        f = 0.25+ clamp(pow(abs(f), 13.0) * 13.0, 0.0, q.y*.14);\n\n        if( lint1.w > 0. ) {\n            col += (f*LIGHTINTENSITY*exp(-lint1.w*7.0)) * getLightColor(lint1.xyz);\n        }  \n\n        col += 0.25*f*(0.2+backgroundColor);\n\n        // post processing\n        col = pow( clamp(col,0.0,1.0), vec3(0.4545) );\n        col *= 1.2*vec3(1.,0.99,0.95);   \n        col = clamp(1.06*col-0.03, 0., 1.);  \n        q.y = (q.y-.12)*(1./0.76);\n        col *= 0.5 + 0.5*pow( 16.0*q.x*q.y*(1.0-q.x)*(1.0-q.y), 0.1 ); \n\n        fragColor = vec4( col, 1.0 );\n    }\n}\n",
  "meta": {
    "name": "Tokyo",
    "author": "reinder",
    "version": 0.1,
    "uniforms": {},
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false,
    "originalName": "Tokyo",
    "alpha": 1,
    "enabled": false,
    "compositeOperation": "normal"
  }
};

/***/ })
/******/ ]);