/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  "props": {
    "mX": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse X"
    },
    "mY": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Y"
    },
    "mZ": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse Z"
    },
    "mW": {
      "type": "float",
      "default": 0.5,
      "label": "Mouse W"
    }
  },
  "fragmentShader": "uniform float mX;\nuniform float mY;\nuniform float mZ;\nuniform float mW;\n// \"Ocean Structure\" by dr2 - 2017\n// License: Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License\n\n#define REAL_WAVE 0   // real (=1) or fake (=0, less work) water waves\n#define N_REFL    3   // number of reflections (1-4, 0 = none)\n\nfloat PrBoxDf (vec3 p, vec3 b);\nfloat PrSphDf (vec3 p, float s);\nfloat PrSphAnDf (vec3 p, float r, float w);\nfloat PrCylDf (vec3 p, float r, float h);\nfloat PrTorusDf (vec3 p, float ri, float rc);\nfloat PrCapsDf (vec3 p, float r, float h);\nfloat PrCapsAnDf (vec3 p, float r, float w, float h);\nfloat PrFlatCylDf (vec3 p, float rhi, float rlo, float h);\nfloat Noisefv2 (vec2 p);\nfloat Noisefv3 (vec3 p);\nfloat Fbm1 (float p);\nfloat Fbm2 (vec2 p);\nfloat Fbm3 (vec3 p);\nvec3 VaryNf (vec3 p, vec3 n, float f);\nvec3 HsvToRgb (vec3 c);\nvec2 Rot2D (vec2 q, float a);\n\nvec3 qHit, sunDir, smkPos;\nfloat dstFar, tCur, smkRadEx, smkRadIn, smkPhs, smkHt, tWav;\nint idObj;\nbool isNite;\nconst int idBase = 1, idPlat = 2, isShel = 3, idFrm = 4, idDway = 5,\n   idTwr = 6, idBrg = 7, idBrCab = 8, idRdw = 9;\nconst float pi = 3.14159;\n\nfloat BridgeDf (vec3 p, float dMin)\n{\n  float cbRad = 0.06;\n  vec3 q, qq;\n  float d, cLen, wRd;\n  wRd = 1.;\n  q = p;  q.x = abs (q.x) - wRd;  q.y -= -0.3;\n  d = PrBoxDf (q, vec3 (0.15, 5., 0.15));\n  q = p;  q.y -= 4.85;\n  d = min (d, PrBoxDf (q, vec3 (wRd + 0.15, 0.15, 0.15)));\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idBrg; }\n  qq = p;  qq.x = abs (qq.x) - wRd + 0.07;  qq.z = abs (qq.z);\n  q = qq;  q.y -= 4.92;\n  q.yz = Rot2D (q.yz, -0.1 * pi);\n  q.z -= 9.5;\n  d = PrCylDf (q, cbRad, 9.5);\n  q = qq;  q.y -= 4.82;\n  q.yz = Rot2D (q.yz, -0.15 * pi);\n  q.z -= 6.4;\n  d = min (d, PrCylDf (q, cbRad, 6.4));\n  q = qq;  q.y -= 4.77;\n  q.yz = Rot2D (q.yz, -0.26 * pi);\n  q.z -= 4.;\n  d = min (d, PrCylDf (q, cbRad, 4.));\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idBrCab; }\n  return dMin;\n}\n\nfloat CentStrucDf (vec3 p, float dMin, float ar)\n{\n  float cRad = 6., cLen = 8., ww = 0.03, wThk = 0.05,\n     doorHt = 1.6, doorWd = 1.4;\n  vec3 q;\n  vec2 qo;\n  float d, dd;\n  q = p;  q.y -= -1.05;\n  d = PrCylDf (q.xzy, 8.5, 0.15);\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idPlat; }\n  d = PrTorusDf (vec3 (q.xz, abs (abs (q.y - 1.1) - 0.4) - 0.2), 0.03, 8.5);\n  q.xz = Rot2D (q.xz, 2. * pi * (floor (16. * ar) + 0.5) / 16.);\n  q.xy -= vec2 (-8.5, 0.9);\n  d = min (d, PrCylDf (q.xzy, 0.05, 0.82));\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idBrCab; }\n  q = p;\n  qo = Rot2D (q.xz, 2. * pi * (floor (4. * ar) + 0.5) / 4.);\n  q.xz = qo;  q.y -= cLen + 1.2 * doorHt - 9.;\n  dd = PrFlatCylDf (q.yzx, doorHt, doorWd, 0.);\n  q = p;  q.y -= cLen - 9.;\n  d = max (max (max (PrCapsAnDf (q.xzy, cRad, wThk, cLen), - q.y), q.y - 1.635 * cLen), - dd);\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = isShel; }\n  q.xz = Rot2D (q.xz, 2. * pi * (floor (8. * ar) + 0.5) / 8.);\n  d = max (max (max (PrCapsAnDf (q.xzy, cRad, 0.2, cLen),\n     min (abs (mod (q.y, 2.) - 1.) - 0.1,\n     dot (vec2 (q.x, abs (q.z)), vec2 (sin (0.04 * 2. * pi / 16.), cos (0.04 * 2. * pi / 16.))))),\n     - q.y), - dd);\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idFrm; }\n  q = p;  q.xz = qo;  q.xy -= vec2 (-0.98 * cRad, cLen + 1.2 * doorHt - 9.);\n  d = max (max (max (PrFlatCylDf (q.yzx, doorHt, doorWd, 0.1 * cRad),\n     - PrFlatCylDf (q.yzx, doorHt - ww, doorWd - ww, 0.)),\n     - (q.y + 2. * doorHt - ww - wThk)), - (q.y + 1.2 * doorHt));\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idDway; }\n  return dMin;\n}\n\nfloat CornStrucDf (vec3 p, float dMin)\n{\n  vec3 q;\n  float d, a;\n  q = p;  q.y -= -1.2;\n  d = PrCylDf (q.xzy, 3.2, 0.15);\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idPlat; }\n  q = p;  q.y -= 1.;\n  d = max (PrCapsAnDf  (q.xzy, 2.5, 0.1, 3.), -2.2 - q.y);\n  q = p;  q.y -= 7.;\n  d = min (d, max (PrCapsDf (q.xzy, 0.7, 2.), -1. - q.y));\n  q = p;\n  a = (length (q.xz) > 0.) ? atan (q.z, - q.x) / (2. * pi) : 0.;\n  q.xz = Rot2D (q.xz, 2. * pi * (floor (4. * a + 0.5) / 4.));\n  d = max (d, - PrFlatCylDf (q.yzx, 1.5, 1., 0.));\n  q = p;\n  q.xz = Rot2D (q.xz, 2. * pi * (floor (16. * a) + 0.5) / 16.);\n  q.y -= 4.3;\n  d = max (d, - (length (max (abs (q.yz) - vec2 (0.6, 0.08), 0.)) - 0.2));\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idTwr; }\n  return dMin;\n}\n\nfloat ObjDf (vec3 p)\n{\n  vec3 q;\n  float d, dMin, hs, wRd, ar;\n  dMin = dstFar;\n  hs = 5.;\n  q = p;  q.xz = abs (q.xz) - 4.;\n  d = max (PrSphAnDf (q, 4.85, 0.15), - min (3.9 - q.y, q.y));\n  q.y -= 0.5;\n  d = max (d, 2.2 - min (length (q.yz), length (q.xy)));\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idBase; }\n  q = p;  q.xz = abs (q.xz) - 20.;\n  d = max (PrSphAnDf (q, 4.85, 0.15), - min (3.9 - q.y, q.y));\n  q.y -= 0.5;\n  d = max (d, 2.2 - min (length (q.yz), length (q.xy)));\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idBase; }\n  wRd = 1.;\n  q = p;  q.xz = abs (q.xz) - 20.7 + wRd;\n  d = max (max (length (max (q.xz - wRd, 0.)) - 0.3,\n     - (length (max (q.xz + wRd, 0.)) - 0.3)), abs (q.y - hs + 1.) - 0.1);\n  if (d < dMin) { dMin = d;  qHit = q;  idObj = idRdw; }\n  q = p;\n  ar = (length (p.xz) > 0.) ? atan (p.z, - p.x) / (2. * pi) : 0.;\n  q.y -= hs;\n  dMin = CentStrucDf (q, dMin, ar);\n  q = p;  q.y -= hs;  q.xz = abs (q.xz) - vec2 (20.);\n  dMin = CornStrucDf (q, dMin);\n  q = p;  q.y -= hs;\n  q.xz = Rot2D (q.xz, 2. * pi * (floor (4. * ar + 0.5) / 4.));\n  q.x += 20.;\n  dMin = BridgeDf (q, dMin);\n  return dMin;\n}\n\nfloat ObjRay (vec3 ro, vec3 rd)\n{\n  float dHit, d;\n  dHit = 0.;\n  for (int j = 0; j < 120; j ++) {\n    d = ObjDf (ro + dHit * rd);\n    dHit += d;\n    if (d < 0.001 || dHit > dstFar) break;\n  }\n  return dHit;\n}\n\nvec3 ObjNf (vec3 p)\n{\n  vec4 v;\n  vec3 e = vec3 (0.001, -0.001, 0.);\n  v = vec4 (ObjDf (p + e.xxx), ObjDf (p + e.xyy), ObjDf (p + e.yxy), ObjDf (p + e.yyx));\n  return normalize (vec3 (v.x - v.y - v.z - v.w) + 2. * v.yzw);\n}\n\nfloat WaveHt (vec2 p)\n{\n  mat2 qRot = mat2 (0.8, -0.6, 0.6, 0.8);\n  vec4 t4, v4;\n  vec2 t;\n  float wFreq, wAmp, ht;\n  wFreq = 1.;\n  wAmp = 1.;\n  ht = 0.;\n  for (int j = 0; j < 3; j ++) {\n    p *= qRot;\n    t = tWav * vec2 (1., -1.);\n    t4 = (p.xyxy + t.xxyy) * wFreq;\n    t = vec2 (Noisefv2 (t4.xy), Noisefv2 (t4.zw));\n    t4 += 2. * t.xxyy - 1.;\n    v4 = (1. - abs (sin (t4))) * (abs (sin (t4)) + abs (cos (t4)));\n    ht += wAmp * dot (pow (1. - sqrt (v4.xz * v4.yw), vec2 (8.)), vec2 (1.));\n    wFreq *= 2.;\n    wAmp *= 0.5;\n  }\n  return ht;\n}\n\nvec3 WaveNf (vec3 p, float d)\n{\n  vec3 vn;\n  vec2 e;\n  e = vec2 (max (0.01, 0.005 * d * d), 0.);\n  p *= 0.3;\n  vn.xz = 0.4 * (WaveHt (p.xz) - vec2 (WaveHt (p.xz + e.xy),  WaveHt (p.xz + e.yx)));\n  vn.y = e.x;\n  return normalize (vn);\n}\n\n#if REAL_WAVE\n\nfloat WaveRay (vec3 ro, vec3 rd)\n{\n  vec3 p;\n  float dHit, h, s, sLo, sHi, f1, f2;\n  dHit = dstFar;\n  f1 = 0.4;\n  f2 = 0.3;\n  s = max (- (ro.y - 1.2 * f1) / rd.y, 0.);\n  sLo = s;\n  for (int j = 0; j < 80; j ++) {\n    p = ro + s * rd;\n    h = p.y - f1 * WaveHt (f2 * p.xz);\n    if (h < 0.) break;\n    sLo = s;\n    s += max (0.3, h) + 0.005 * s;\n    if (s >= dstFar) break;\n  }\n  if (h < 0.) {\n    sHi = s;\n    for (int j = 0; j < 5; j ++) {\n      s = 0.5 * (sLo + sHi);\n      p = ro + s * rd;\n      h = step (0., p.y - f1 * WaveHt (f2 * p.xz));\n      sLo += h * (s - sLo);\n      sHi += (1. - h) * (s - sHi);\n    }\n    dHit = sHi;\n  }\n  return dHit;\n}\n\n#endif\n\nfloat SmokeDens (vec3 p)\n{\n  mat2 rMat;\n  vec3 q, u;\n  float f;\n  f = PrTorusDf (p.xzy, smkRadIn, smkRadEx);\n  if (f < 0.) {\n    q = p.xzy / smkRadEx;\n    u = normalize (vec3 (q.xy, 0.));\n    q -= u;\n    rMat = mat2 (vec2 (u.x, - u.y), u.yx);\n    q.xy = rMat * q.xy;\n    q.xz = Rot2D (q.xz, 2.5 * tCur);\n    q.xy = q.xy * rMat;\n    q += u;\n    q.xy = Rot2D (q.xy, 0.1 * tCur);\n    f = smoothstep (0., smkRadIn, - f) * Fbm3 (10. * q);\n  } else f = 0.;\n  return f;\n}\n\nvec4 SmokeCol (vec3 ro, vec3 rd, float dstObj)\n{\n  vec4 col4;\n  vec3 q;\n  float densFac, dens, d, h, sh;\n  d = 0.;\n  for (int j = 0; j < 150; j ++) {\n    q = ro + d * rd;\n    q.xz = abs (q.xz);\n    q -= smkPos;\n    h = PrTorusDf (q.xzy, smkRadIn, smkRadEx);\n    d += h;\n    if (h < 0.001 || d > dstFar) break;\n  }\n  col4 = vec4 (0.);\n  if (d < min (dstObj, dstFar)) {\n    densFac = 1.45 * (1.08 - pow (smkPhs, 1.5));\n    for (int j = 0; j < 150; j ++) {\n      q = ro + d * rd;\n      q.xz = abs (q.xz);\n      q -= smkPos;\n      dens = SmokeDens (q);\n      sh = 0.3 + 0.7 * smoothstep (-0.3, 0.1, dens - SmokeDens (q + 0.1 * sunDir));\n      col4 += densFac * dens * (1. - col4.w) * vec4 (sh * vec3 (0.9) - col4.rgb, 0.3);\n      d += 2.2 * smkRadEx / 150.;\n      if (col4.w > 0.99 || d > dstFar) break;\n    }\n  }\n  if (isNite) col4.rgb *= vec3 (0.3, 0.4, 0.3);\n  return col4;\n}\n\nvec4 ObjCol (vec3 n)\n{\n  vec4 col;\n  if (idObj == idBase) col = vec4 (0.3, 0.4, 0.1, 0.1);\n  else if (idObj == idPlat) col = vec4 (0.4, 0.4, 0.3, 0.1);\n  else if (idObj == isShel) col = vec4 (0.5, 0.5, 0.5, 0.3);\n  else if (idObj == idFrm) col = vec4 (0.8, 0.8, 0.9, 0.5);\n  else if (idObj == idDway) col = vec4 (0.7, 0.8, 0.7, 0.3);\n  else if (idObj == idTwr) col = vec4 (0.7, 0.7, 0.6, 0.3);\n  else if (idObj == idBrg) col = vec4 (1., 0.3, 0.3, 0.3);\n  else if (idObj == idBrCab) col = vec4 (0.9, 0.9, 1., 0.5);\n  else if (idObj == idRdw) col = vec4 (0.4, 0.3, 0.3, 0.1);\n  return col;\n}\n\nvec4 AurCol (vec3 ro, vec3 rd)\n{\n  vec4 col, mCol;\n  vec3 p, dp;\n  float ar;\n  dp = rd / rd.y;\n  p = ro + (40. - ro.y) * dp;\n  col = vec4 (0.);\n  mCol = vec4 (0.);\n  tWav = 0.05 * tCur;\n  for (float ns = 0.; ns < 50.; ns ++) {\n    p += dp;\n    ar = 0.05 - clamp (0.06 * WaveHt (0.01 * p.xz), 0., 0.04);\n    mCol = mix (mCol, ar * vec4 (HsvToRgb (vec3 (0.34 + 0.007 * ns, 1., 1. - 0.02 * ns)), 1.), 0.5);\n    col += mCol;\n  }\n  return col;\n}\n\nvec3 NtSkyCol (vec3 rd)\n{\n  vec3 rds;\n  rds = floor (2000. * rd);\n  rds = 0.00015 * rds + 0.1 * Noisefv3 (0.0005 * rds.yzx);\n  for (int j = 0; j < 19; j ++) rds = abs (rds) / dot (rds, rds) - 0.9;\n  return 0.3 * vec3 (1., 1., 0.9) * min (1., 0.5e-3 * pow (min (6., length (rds)), 5.));\n}\n\nvec3 BgCol (vec3 ro, vec3 rd)\n{\n  vec3 col;\n  float f, a;\n  if (rd.y > 0.) {\n    a = atan (rd.x, - rd.z);\n    if (rd.y < 0.03 * Fbm1 (32. * a) + 0.005)\n       col = (isNite ? vec3 (0.07, 0.1, 0.07) : vec3 (0.4, 0.5, 0.7)) * (1. - 0.3 * Fbm2 (128. * vec2 (a, rd.y)));\n    else {\n      if (isNite) {\n        vec4 aCol = AurCol (ro, rd);\n        col = (1. - 0.5 * aCol.a) * NtSkyCol (rd) + 0.6 * aCol.rgb;\n      } else {\n        ro.xz += 2. * tCur;\n        col = vec3 (0.2, 0.3, 0.6) + 0.2 * (1. - max (rd.y, 0.)) +\n           0.1 * pow (max (dot (rd, sunDir), 0.), 16.);\n        f = Fbm2 (0.02 * (ro.xz + rd.xz * (100. - ro.y) / max (rd.y, 0.01)));\n        col = mix (col, vec3 (1.), 0.2 + 0.8 * f * rd.y);\n      }\n    }\n  } else {\n    col = vec3 (0.6, 0.5, 0.3);\n    if (- ro.y / rd.y < dstFar) {\n      ro += - (ro.y / rd.y) * rd;\n      col *= 1.1 - 0.2 * Noisefv2 (30. * ro.xz);\n    }\n    col = mix (col, 0.9 * (vec3 (0.4, 0.2, 0.1) + 0.2) + 0.1, pow (1. + rd.y, 5.));\n  }\n  return col;\n}\n\nvec4 GlowCol (vec3 ro, vec3 rd, float dstObj)\n{\n  vec3 gloDir;\n  float gloDist, wGlow, s;\n  wGlow = 0.;\n  for (float j = 0.; j < 4.; j ++) {\n    gloDir = vec3 (20., 9.3, 20.) * (1. - 2. * vec3 (floor (j / 2.), 0., mod (j, 2.))) - ro;\n    gloDist = length (gloDir);\n    s = dot (rd, normalize (gloDir));\n    if (s > 0. && gloDist < dstObj) wGlow += 1. - smoothstep (1., 2., sqrt (1. - s * s) * gloDist);\n  }\n  gloDir = vec3 (0., 15.5, 0.) - ro;\n  gloDist = length (gloDir);\n  s = dot (rd, normalize (gloDir));\n  if (s > 0. && gloDist < dstObj) wGlow += 1. - smoothstep (2., 3., sqrt (1. - s * s) * gloDist);\n  return (0.6 + 0.4 * sin (0.3 * 2. * pi * tCur)) * clamp (wGlow, 0., 1.) * vec4 (1., 0.5, 0.3, 1.);\n}\n\nvec3 ShowScene (vec3 ro, vec3 rd)\n{\n  vec4 objCol, smkCol, smkColR, smkColW, glwCol, glwColR, glwColW;\n  vec3 col, vn;\n  float dstObj, dstWat, reflCol;\n  bool wRefl;\n  col = vec3 (0.2, 0.2, 0.);\n  wRefl = false;\n  dstObj = ObjRay (ro, rd);\n  smkCol = SmokeCol (ro, rd, dstObj);\n  glwCol = GlowCol (ro, rd, dstObj);\n  glwColR = vec4 (0.);\n  glwColW = vec4 (0.);\n  smkColR = vec4 (0.);\n  smkColW = vec4 (0.);\n  tWav = 0.4 * tCur;\n  reflCol = 1.;\n  if (N_REFL >= 2 && dstObj < dstFar && idObj == isShel) {\n    if (length (qHit.xz) > 6. || qHit.y >= 8.8) {\n      ro += dstObj * rd;\n      vn = ObjNf (ro);\n      rd = reflect (rd, vn);\n      ro += 0.01 * rd;\n      dstObj = ObjRay (ro, rd);\n      smkColR = SmokeCol (ro, rd, dstObj);\n      glwColR = GlowCol (ro, rd, dstObj);\n      reflCol *= 0.9;\n    }\n  }\n  if (N_REFL >= 1 && rd.y < 0.) {\n#if REAL_WAVE\n    dstWat = WaveRay (ro, rd);\n#else\n    dstWat = - ro.y / rd.y;\n#endif\n    if (dstWat < min (dstObj, dstFar)) {\n      wRefl = true;\n      ro += dstWat * rd;\n      vn = WaveNf (ro, dstWat);\n      rd = reflect (rd, vn);\n      ro += 0.01 * rd;\n      dstObj = ObjRay (ro, rd);\n      smkColW = SmokeCol (ro, rd, dstObj);\n      glwColW = GlowCol (ro, rd, dstObj);\n      if (N_REFL >= 3 && dstObj < dstFar && idObj == isShel) {\n        ro += dstObj * rd;\n        vn = ObjNf (ro);\n        rd = reflect (rd, vn);\n        if (N_REFL == 4) {\n          ro += 0.01 * rd;\n          dstObj = ObjRay (ro, rd);\n        } else {\n          dstObj = dstFar;\n        }\n      }\n      reflCol *= 0.7;\n    }\n  }\n  if (dstObj < dstFar) {\n    ro += dstObj * rd;\n    vn = ObjNf (ro);\n    if (idObj == idRdw) vn = VaryNf (5. * qHit, vn, 1.);\n    else if (idObj == idBase) vn = VaryNf (2. * floor (16. * qHit), vn, 2.);\n    objCol = ObjCol (vn);\n    if (isNite) col = objCol.rgb * vec3 (0.3, 0.35, 0.3) * (0.2 + 0.8 * max (0.,vn.y));\n    else col = objCol.rgb * (0.2 + 0.8 * max (0., max (dot (vn, sunDir), 0.))) + \n       objCol.a * pow (max (dot (normalize (sunDir - rd), vn), 0.), 64.);\n  } else if (rd.y > 0.) {\n    col = BgCol (ro, rd);\n  } else {\n#if N_REFL == 0\n    dstWat = - ro.y / rd.y;\n#endif\n    col = BgCol (ro + dstWat * rd, reflect (rd, vec3 (0., 1., 0.)));\n    reflCol = 0.7;\n  }\n  col = clamp (reflCol * col, 0., 1.);\n  col = mix (col, glwCol.rgb, glwCol.a);\n  col = mix (col, glwColR.rgb, glwColR.a);\n  col = mix (col, smkCol.rgb, smkCol.a);\n  col = mix (col, smkColR.rgb, smkColR.a);\n  if (wRefl) {\n    col = mix (col, reflCol * glwColW.rgb, glwColW.a);\n    col = mix (col, reflCol * smkColW.rgb, smkColW.a);\n    col = mix (mix (vec3 (0., 0.1, 0.), vec3 (0., 0.05, 0.05),\n       smoothstep (0.4, 0.6, Fbm2 (0.5 * ro.xz))), col, 1. - pow (abs (rd.y), 4.));\n  }\n  return clamp (col, 0., 1.);\n}\n\nvoid mainImage (out vec4 fragColor, in vec2 fragCoord)\n{\nvec4 iMouse = vec4(mX * iResolution.x, mY * iResolution.y, mZ * iResolution.x, mW * iResolution.y);\n\n  mat3 vuMat;\n  vec4 mPtr;\n  vec3 ro, rd;\n  vec2 uv, ori, ca, sa;\n  float el, az;\n  uv = 2. * fragCoord.xy / iResolution.xy - 1.;\n  uv.x *= iResolution.x / iResolution.y;\n  tCur = iTime;\n  mPtr = iMouse;\n  mPtr.xy = mPtr.xy / iResolution.xy - 0.5;\n  smkPhs = mod (0.15 * tCur + 0.3, 1.);\n  smkPos = vec3 (20., 9. + 10. * smkPhs, 20.);\n  smkRadIn = 0.6 * (0.1 + 0.9 * smoothstep (0.01, 0.1, smkPhs));\n  smkRadEx = smkRadIn + 2.5;\n  dstFar = 140.;\n  isNite = true;\n  az = 0.33 * pi;\n  el = -0.016 * pi;\n  if (mPtr.z > 0.) {\n    if (mPtr.x > 0.45 && mPtr.y < -0.45) isNite = false;\n    else {\n      az += pi * mPtr.x;\n      el += 0.05 * pi * mPtr.y;\n    }\n  } else {\n    az += 0.002 * pi * tCur;\n    el += 0.01 * pi * sin (0.01 * pi * tCur);\n  }\n  el = clamp (el, -0.4 * pi, -0.01 * pi);\n  ori = vec2 (el, az);\n  ca = cos (ori);\n  sa = sin (ori);\n  vuMat = mat3 (ca.y, 0., - sa.y, 0., 1., 0., sa.y, 0., ca.y) *\n          mat3 (1., 0., 0., 0., ca.x, - sa.x, 0., sa.x, ca.x);\n  ro = vuMat * vec3 (0., 10., -100.);\n  rd = vuMat * normalize (vec3 (uv, 4.2));\n  sunDir = vuMat * normalize (vec3 (1., 1., -1.));\n  fragColor = vec4 (ShowScene (ro, rd), 1.);\n}\n\nfloat PrBoxDf (vec3 p, vec3 b)\n{\n  vec3 d;\n  d = abs (p) - b;\n  return min (max (d.x, max (d.y, d.z)), 0.) + length (max (d, 0.));\n}\n\nfloat PrSphDf (vec3 p, float s)\n{\n  return length (p) - s;\n}\n\nfloat PrSphAnDf (vec3 p, float r, float w)\n{\n  return abs (length (p) - r) - w;\n}\n\nfloat PrCylDf (vec3 p, float r, float h)\n{\n  return max (length (p.xy) - r, abs (p.z) - h);\n}\n\nfloat PrCapsDf (vec3 p, float r, float h)\n{\n  return length (p - vec3 (0., 0., h * clamp (p.z / h, -1., 1.))) - r;\n}\n\nfloat PrCapsAnDf (vec3 p, float r, float w, float h)\n{\n  p.z = abs (p.z);\n  return max (length (p - vec3 (0., 0., min (p.z, h + w))) - r,\n     - length (p - vec3 (0., 0., min (p.z, h - w))) + r) - w;\n}\n\nfloat PrFlatCylDf (vec3 p, float rhi, float rlo, float h)\n{\n  float d;\n  d = length (p.xy - vec2 (rhi * clamp (p.x / rhi, -1., 1.), 0.)) - rlo;\n  if (h > 0.) d = max (d, abs (p.z) - h);\n  return d;\n}\n\nfloat PrTorusDf (vec3 p, float ri, float rc)\n{\n  return length (vec2 (length (p.xy) - rc, p.z)) - ri;\n}\n\nconst float cHashM = 43758.54;\n\nvec2 Hashv2f (float p)\n{\n  return fract (sin (p + vec2 (0., 1.)) * cHashM);\n}\n\nvec2 Hashv2v2 (vec2 p)\n{\n  vec2 cHashVA2 = vec2 (37., 39.);\n  return fract (sin (vec2 (dot (p, cHashVA2), dot (p + vec2 (1., 0.), cHashVA2))) * cHashM);\n}\n\nvec4 Hashv4v3 (vec3 p)\n{\n  vec3 cHashVA3 = vec3 (37., 39., 41.);\n  vec2 e = vec2 (1., 0.);\n  return fract (sin (vec4 (dot (p + e.yyy, cHashVA3), dot (p + e.xyy, cHashVA3),\n     dot (p + e.yxy, cHashVA3), dot (p + e.xxy, cHashVA3))) * cHashM);\n}\n\nfloat Noiseff (float p)\n{\n  vec2 t;\n  float ip, fp;\n  ip = floor (p);\n  fp = fract (p);\n  fp = fp * fp * (3. - 2. * fp);\n  t = Hashv2f (ip);\n  return mix (t.x, t.y, fp);\n}\n\nfloat Noisefv2 (vec2 p)\n{\n  vec2 t, ip, fp;\n  ip = floor (p);  \n  fp = fract (p);\n  fp = fp * fp * (3. - 2. * fp);\n  t = mix (Hashv2v2 (ip), Hashv2v2 (ip + vec2 (0., 1.)), fp.y);\n  return mix (t.x, t.y, fp.x);\n}\n\nfloat Noisefv3 (vec3 p)\n{\n  vec4 t;\n  vec3 ip, fp;\n  ip = floor (p);\n  fp = fract (p);\n  fp *= fp * (3. - 2. * fp);\n  t = mix (Hashv4v3 (ip), Hashv4v3 (ip + vec3 (0., 0., 1.)), fp.z);\n  return mix (mix (t.x, t.y, fp.x), mix (t.z, t.w, fp.x), fp.y);\n}\n\nfloat Fbm1 (float p)\n{\n  float f, a;\n  f = 0.;\n  a = 1.;\n  for (int i = 0; i < 5; i ++) {\n    f += a * Noiseff (p);\n    a *= 0.5;\n    p *= 2.;\n  }\n  return f * (1. / 1.9375);\n}\n\nfloat Fbm2 (vec2 p)\n{\n  float f, a;\n  f = 0.;\n  a = 1.;\n  for (int i = 0; i < 5; i ++) {\n    f += a * Noisefv2 (p);\n    a *= 0.5;\n    p *= 2.;\n  }\n  return f * (1. / 1.9375);\n}\n\nfloat Fbm3 (vec3 p)\n{\n  float f, a;\n  f = 0.;\n  a = 1.;\n  for (int i = 0; i < 5; i ++) {\n    f += a * Noisefv3 (p);\n    a *= 0.5;\n    p *= 2.;\n  }\n  return f * (1. / 1.9375);\n}\n\nfloat Fbmn (vec3 p, vec3 n)\n{\n  vec3 s;\n  float a;\n  s = vec3 (0.);  \n  a = 1.;\n  for (int i = 0; i < 5; i ++) {\n    s += a * vec3 (Noisefv2 (p.yz), Noisefv2 (p.zx), Noisefv2 (p.xy));\n    a *= 0.5;  \n    p *= 2.;\n  }\n  return dot (s, abs (n));\n}\n\nvec3 VaryNf (vec3 p, vec3 n, float f)\n{\n  vec3 g;\n  vec2 e = vec2 (0.1, 0.);\n  g = vec3 (Fbmn (p + e.xyy, n), Fbmn (p + e.yxy, n), Fbmn (p + e.yyx, n)) - Fbmn (p, n);\n  return normalize (n + f * (g - n * dot (n, g)));\n}\n\nvec3 HsvToRgb (vec3 c)\n{\n  vec3 p;\n  p = abs (fract (c.xxx + vec3 (1., 2./3., 1./3.)) * 6. - 3.);\n  return c.z * mix (vec3 (1.), clamp (p - 1., 0., 1.), c.y);\n}\n\nvec2 Rot2D (vec2 q, float a)\n{\n  return q * cos (a) + q.yx * sin (a) * vec2 (-1., 1.);\n}\n",
  "meta": {
    "name": "Ocean Structure",
    "author": "dr2",
    "version": 0.1,
    "uniforms": {},
    "type": "shader",
    "previewWithOutput": true,
    "flipY": false,
    "originalName": "Ocean Structure",
    "alpha": 1,
    "enabled": false,
    "compositeOperation": "normal"
  }
};

/***/ })
/******/ ]);